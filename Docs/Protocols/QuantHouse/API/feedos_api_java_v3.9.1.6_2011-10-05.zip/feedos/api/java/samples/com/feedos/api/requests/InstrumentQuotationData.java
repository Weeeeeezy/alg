package com.feedos.api.requests;
import com.feedos.api.core.Any;
import com.feedos.api.core.PDU;
import com.feedos.api.core.PolymorphicInstrumentCode;

/*
 * (c) Copyright 2005 QuantHouse
 * All Rights Reserved.
 * 
 * @author fenouil
 */
 
/**
 *  container class: an instrument code and related Quotation data(a bunch of <i>variables</i> identified by a <i>Tag Number</i>)
 * 
 */ 
 

public class InstrumentQuotationData {
	
	private int m_max_orderbook_depth = 0;	// dynamically computed from data received (first snapshot+updates)
	private PolymorphicInstrumentCode instrumentCode = new PolymorphicInstrumentCode();
	private ListOfTagValue m_quotation_values;
	private OrderBook m_orderbook;
	
	/**
	 * accessor 	get the OrderBook
	 * 
	 * @return the order book
	 */
	final public OrderBook getOrderBook ()
	{
		return m_orderbook;
	}
	
	final public ListOfTagValue getQuotationValues()
	{
		return m_quotation_values;
	}
		
	public PolymorphicInstrumentCode getInstrumentCode() {
		return instrumentCode;
	}
	
	final double getTagByNumber_safe_double_nolock (int tag_num)
	{
		Any ptr = getTagByNumber (tag_num);
		return (ptr==null) ? 0 : ptr.get_float64();
	}
	
	/**
	 * accessor 	retrieve the value for the given TagNumber
	 * 
	 * @param tag_num	the tag to look for
	 * @return the tag value, or NULL if not found
	 */
	final public synchronized Any getTagByNumber (int tag_num)
	{
		return m_quotation_values.getTagByNumber(tag_num);
	}
	
	/**
	 *  	remove the given TagNumber
	 * 
	 * @param tag_num	the tag to remove
	 * @return true if it was erased, false if it was not found
	 */
	final public synchronized boolean removeTagByNumber (int tag_num)
	{
		return m_quotation_values.removeTagByNumber(tag_num);
	}
		
	/**
	 * accessor 	get all tag numbers
	 * @see #getAllTagValues_nolock
	 * not thread safe. Use synchronized() on the object
	 * 
	 * @return the list of tag numbers
	 */
	final public int[] getAllTagNumbers_nolock ()
	{
		int[] copy = new  int[m_quotation_values.getNbTag()];
  		for (int i=0; i<m_quotation_values.getNbTag(); ++i) {
  			copy[i] = m_quotation_values.getTagNumberByIndex(i);
		}		
		return copy;
	}
	
	/**
	 * accessor 	get all tag values
	 * @see #getAllTagNumbers_nolock
	 * not thread safe. Use synchronized() on the object
	 * 
	 * @return the list of tag values
	 */
	final public Any[] getAllTagValues_nolock ()
	{
		Any[] copy = new  Any[m_quotation_values.getNbTag()];
  		for (int i=0; i<m_quotation_values.getNbTag(); ++i) {
  			copy[i] = m_quotation_values.getTagByIndex(i);
		}		
		return copy;
	}
	
	/**
	 * reloadValues		reset and reload tag values (from a Snapshot for example)
	 * 
	 * @param the_quot_tag_nums				the list of quotation tag numbers
	 * @param the_quot_values				the list of quotation tag values
	 */
	public synchronized void reloadValues 
				(	int[] the_quot_tag_nums, 
					Any[] the_quot_values
				)
	{
		m_quotation_values = new ListOfTagValue(the_quot_tag_nums, the_quot_values);				
	}
	
	
	/**
	 * clearValues		clear all values. Orderbook is not affected.
	 */
	public synchronized void clearValues() 
	{
		m_quotation_values = new ListOfTagValue();
	}

	
	/**
	 * constructor
	 * 
	 * @param the_internal_instrument_code	the instrument code (use it with PolymorphicInstrumentCode#merge_internal_code if applicable)
	 * @param the_quot_tag_nums				the list of quotation tag numbers
	 * @param the_quot_values				the list of quotation tag values
	 * @param the_orderbook					the limits
	 */
	public InstrumentQuotationData (	int the_internal_instrument_code, 
								int[] the_quot_tag_nums, 
								Any[] the_quot_values,
								OrderBook the_orderbook
								) 
	{
		instrumentCode.set_internal_code(the_internal_instrument_code);
		reloadValues (the_quot_tag_nums,the_quot_values);
		setOrderbook(the_orderbook);
	}

	
	/**
	 * constructor
	 * 
	 * @param the_internal_instrument_code	the instrument code (use it with PolymorphicInstrumentCode#merge_internal_code if applicable)
	 * @param the_orderbook					the limits
	 */
	public InstrumentQuotationData (	int the_internal_instrument_code, 
								OrderBook the_orderbook
								) 
	{
		instrumentCode.set_internal_code(the_internal_instrument_code);
		setOrderbook(the_orderbook);
	}

	/**
	 * constructor
	 * 
	 * @param the_internal_instrument_code	the instrument code
	 * @param the_orderbook					the limits
	 */
	public InstrumentQuotationData (	PolymorphicInstrumentCode the_internal_instrument_code, 
								OrderBook the_orderbook
								) 
	{
		instrumentCode = the_internal_instrument_code;
		setOrderbook(the_orderbook);
	}
	

	final void setOrderbook (OrderBook the_orderbook)
	{
		m_orderbook = the_orderbook;
		m_max_orderbook_depth = Math.max (	m_orderbook.getBidSide().getDepth(), 
											m_orderbook.getAskSide().getDepth()
										);
	}
	

	/**
	 * notif processing: "max visible depth"
	 * 
	 * this tells what is the current "max visible depth" of the order book.
	 * Limits that go beyond that should be discarded
	 * 
	 * 
	 */
	public synchronized void update_with_MaxVisibleDepth
							(	
									int cur_max_depth
							)
	{
		m_max_orderbook_depth = cur_max_depth;
		m_orderbook.set_max_depth(cur_max_depth);
	}
	
	/**
	 * notif processing: "trade event ext"
	 * 
	 * based on "content mask" some values are updated (LastPrice, TradingStatus, etc)
	 * and other values are extrapolated/adjusted (TotalVolumes, TradingStatus=FAST_MARKET => reset or order book, etc) 
	 *  
	 * 
	 */
	public synchronized void update_with_TradeEventExt 
							(	
									long timestamp, 
									QuotationTradeEventExt trade_event_ext
							)
	{
		double event_price = trade_event_ext.price;		
		Any event_price_ptr = Any.make_float64(event_price);
		
		boolean OCHL_daily = trade_event_ext.content_mask.isSetOCHLdaily();
		
		if (trade_event_ext.content_mask.isSetClose()) {
			m_quotation_values.setOrAddTag (Constants.TAG_PreviousSessionClosingPrice, event_price_ptr);
			if (OCHL_daily) {
				m_quotation_values.setOrAddTag (Constants.TAG_DailyClosingPrice, event_price_ptr);
			}
		} else if (trade_event_ext.content_mask.isSetOpen()) {
			m_quotation_values.setOrAddTag (Constants.TAG_SessionOpeningPrice, event_price_ptr);
			removeTagByNumber(Constants.TAG_SessionHighPrice);
			removeTagByNumber(Constants.TAG_SessionLowPrice);	
			if (OCHL_daily) {
				
				if(trade_event_ext.content_mask.isSetLastPrice())
				{
					m_quotation_values.setOrAddTag (Constants.TAG_DailyOpeningPrice, event_price_ptr);
				}
				else
				{
					removeTagByNumber(Constants.TAG_DailyOpeningPrice);
				}
				
				Any previous_daily_open_timestamp_ptr = getTagByNumber(Constants.TAG_InternalDailyOpenTimestamp);
				
				long previous_daily_open_timestamp = 
					(previous_daily_open_timestamp_ptr==null) ? 0 : previous_daily_open_timestamp_ptr.get_timestamp();

				if( m_quotation_values.tagIsPresent(Constants.TAG_DailyClosingPrice) || m_quotation_values.tagIsPresent(Constants.TAG_DailySettlementPrice) )
				{
					// really a new business day: update "previous" values
					m_quotation_values.setOrAddTag (Constants.TAG_PreviousBusinessDay, Any.make_float64(previous_daily_open_timestamp));			
					m_quotation_values.setOrAddTag (Constants.TAG_PreviousDailyClosingPrice, Any.make_float64(getTagByNumber_safe_double_nolock(Constants.TAG_DailyClosingPrice)));			
					m_quotation_values.setOrAddTag (Constants.TAG_PreviousDailySettlementPrice, Any.make_float64(getTagByNumber_safe_double_nolock(Constants.TAG_DailySettlementPrice)));				
					m_quotation_values.setOrAddTag (Constants.TAG_PreviousDailyTotalVolumeTraded, Any.make_float64(getTagByNumber_safe_double_nolock(Constants.TAG_DailyTotalVolumeTraded)));		
					m_quotation_values.setOrAddTag (Constants.TAG_PreviousDailyTotalAssetTraded, Any.make_float64(getTagByNumber_safe_double_nolock(Constants.TAG_DailyTotalAssetTraded)));
				}
				
				//if( tag_is_present_nolock(Constants.TAG_PreviousSessionClosingPrice) ) 	removeTagByNumber(Constants.TAG_PreviousSessionClosingPrice);			
				if( m_quotation_values.tagIsPresent(Constants.TAG_DailyClosingPrice) ) 			removeTagByNumber(Constants.TAG_DailyClosingPrice); 	
				if( m_quotation_values.tagIsPresent(Constants.TAG_DailySettlementPrice) ) 		removeTagByNumber(Constants.TAG_DailySettlementPrice);			
					
				if( m_quotation_values.tagIsPresent(Constants.TAG_DailyTotalAssetTraded) ) 			m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalAssetTraded, Any.make_float64(0));
				if( m_quotation_values.tagIsPresent(Constants.TAG_DailyTotalVolumeTraded) ) 			m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalVolumeTraded, Any.make_float64(0));
				if( m_quotation_values.tagIsPresent(Constants.TAG_DailyTotalOffBookVolumeTraded) )	m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalOffBookVolumeTraded, Any.make_float64(0));
				if( m_quotation_values.tagIsPresent(Constants.TAG_DailyTotalOffBookAssetTraded) ) 	m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalOffBookAssetTraded, Any.make_float64(0));
				
				removeTagByNumber(Constants.TAG_DailyHighPrice);
				removeTagByNumber(Constants.TAG_DailyLowPrice);	
				
			}
		}
		
		Any tag_tradingstatus = trade_event_ext.Value.getTagByNumber(Constants.TAG_TradingStatus);
		if( tag_tradingstatus != null )	{
			consistant_update_TradingStatus ( tag_tradingstatus.get_enum() );	
		}
		
		if (trade_event_ext.content_mask.isSetBidLimit()) {
			m_orderbook.getBidSide().set_best_limit (trade_event_ext.best_bid_price, trade_event_ext.best_bid_qty);
		}
		if (trade_event_ext.content_mask.isSetAskLimit()) {
			m_orderbook.getAskSide().set_best_limit (trade_event_ext.best_ask_price, trade_event_ext.best_ask_qty);
		}
					
		if (trade_event_ext.content_mask.isSetLastPrice()) {
			m_quotation_values.setOrAddTag (Constants.TAG_LastPrice, event_price_ptr);
			
			if (trade_event_ext.content_mask.isSetLastTradeQty()) {
					
				double event_last_trade_qty = trade_event_ext.last_trade_qty;
					
				if( trade_event_ext.content_mask.isSetOffBookTrade() )
				{
					m_quotation_values.setOrAddTag (Constants.TAG_LastOffBookTradeTimestamp, Any.make_timestamp(timestamp));				
					m_quotation_values.setOrAddTag (Constants.TAG_LastOffBookTradeQty, Any.make_float64(event_last_trade_qty));
					m_quotation_values.setOrAddTag (Constants.TAG_LastOffBookTradePrice, event_price_ptr);
					internal_extrapolate_TotalOffBookVolumeAndOffBookAsset_after_transaction (event_price, event_last_trade_qty);
				}
				else
				{
					m_quotation_values.setOrAddTag (Constants.TAG_LastTradeTimestamp, Any.make_timestamp(timestamp));			
					m_quotation_values.setOrAddTag (Constants.TAG_LastTradeQty, Any.make_float64(event_last_trade_qty));
					m_quotation_values.setOrAddTag (Constants.TAG_LastTradePrice, event_price_ptr);
					internal_extrapolate_TotalVolumeAndAsset_after_transaction (event_price, event_last_trade_qty);
				}
			}
		}
			
		if (trade_event_ext.content_mask.isSetLow()) {
			m_quotation_values.setOrAddTag (Constants.TAG_SessionLowPrice, event_price_ptr);
			if (OCHL_daily) {
				m_quotation_values.setOrAddTag (Constants.TAG_DailyLowPrice, event_price_ptr);
			}
		}
		
		if (trade_event_ext.content_mask.isSetHigh()) {
			m_quotation_values.setOrAddTag (Constants.TAG_SessionHighPrice, event_price_ptr);
			if (OCHL_daily) {
				m_quotation_values.setOrAddTag (Constants.TAG_DailyHighPrice, event_price_ptr);
			}
		}
		
		for(int i = 0; i < trade_event_ext.Value.size(); ++i)
		{
			int tag_num;
			Any tag_value;
			tag_num = trade_event_ext.Value.getTagNums()[i];
			tag_value = trade_event_ext.Value.getTagValues()[i];
			
			m_quotation_values.setOrAddTag(tag_num, tag_value);
		}
		
	}
	
	void internal_extrapolate_TotalVolumeAndAsset_after_transaction (double event_price, double event_last_trade_qty)
	{
		{
			double cur_SessionTotalVolumeTraded = getTagByNumber_safe_double_nolock(Constants.TAG_SessionTotalVolumeTraded);
			m_quotation_values.setOrAddTag (Constants.TAG_SessionTotalVolumeTraded, Any.make_float64 (cur_SessionTotalVolumeTraded + event_last_trade_qty));
		}	

		{
			double cur_DailyTotalVolumeTraded = getTagByNumber_safe_double_nolock(Constants.TAG_DailyTotalVolumeTraded);
			m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalVolumeTraded, Any.make_float64 (cur_DailyTotalVolumeTraded + event_last_trade_qty));
		}	
		
		{
			double cur_SessionTotalAssetTraded = getTagByNumber_safe_double_nolock(Constants.TAG_SessionTotalAssetTraded);
			m_quotation_values.setOrAddTag (Constants.TAG_SessionTotalAssetTraded, Any.make_float64 (cur_SessionTotalAssetTraded + event_price*event_last_trade_qty));
		}	

		{
			double cur_DailyTotalAssetTraded = getTagByNumber_safe_double_nolock(Constants.TAG_DailyTotalAssetTraded);
			m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalAssetTraded, Any.make_float64 (cur_DailyTotalAssetTraded + event_price*event_last_trade_qty));
		}	
	}
	
	void internal_extrapolate_TotalOffBookVolumeAndOffBookAsset_after_transaction (double event_price, double event_last_trade_qty)
	{
		{
			double cur_DailyTotalOffBookVolumeTraded = getTagByNumber_safe_double_nolock(Constants.TAG_DailyTotalOffBookVolumeTraded);
			m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalOffBookVolumeTraded, Any.make_float64 (cur_DailyTotalOffBookVolumeTraded + event_last_trade_qty));
		}	

		{
			double cur_DailyTotalOffBookAssetTraded = getTagByNumber_safe_double_nolock(Constants.TAG_DailyTotalOffBookAssetTraded);
			m_quotation_values.setOrAddTag (Constants.TAG_DailyTotalOffBookAssetTraded, Any.make_float64 (cur_DailyTotalOffBookAssetTraded + event_price*event_last_trade_qty));
		}	
	}
	
	void consistant_update_TradingStatus (int fix_security_status)
	{
		m_quotation_values.setOrAddTag (Constants.TAG_TradingStatus, Any.make_enum(fix_security_status));
		
		switch (fix_security_status) {
		case Constants.FIXSecurityTradingStatus_ReadyToTrade:
			// start of session
			break;
		case Constants.FIXSecurityTradingStatus_NotAvailableForTrading:
			// end of session
			break;
		case Constants.FIXSecurityTradingStatus_FastMarket:
			// orderbook is no more valid
			m_orderbook.reset_limits ();
			break;
		}
	}
	
	/**
	 * notif processing: "orderbook refresh"
	 * 
	 * 
	 */
	public synchronized void update_with_OrderBookRefresh 
							(	
									long timestamp,
									int bid_change_indicator,
									int ask_change_indicator,
									double[] bid_prices, 
									double[] bid_quantities,
									double[] ask_prices, 
									double[] ask_quantities
							)
	{
		m_orderbook.setLastUpdateTimestamp(timestamp);
		internal_update_orderbook_refresh_one_side (bid_change_indicator, bid_prices, bid_quantities, m_orderbook.getBidSide());
		internal_update_orderbook_refresh_one_side (ask_change_indicator, ask_prices, ask_quantities, m_orderbook.getAskSide());		
	}

	
	private final void internal_update_orderbook_refresh_one_side
				(
					int change_indicator, 	
					double[] source_prices, 
					double[] source_quantities, 
					OrderBookSide dest
				)
	{
		boolean is_full;
		int source_start_level;
		if (change_indicator < 0) {
			is_full=true;
			source_start_level=-change_indicator-1;
		} else {
			is_full=false;
			source_start_level=change_indicator;
		}
		
		int dest_size = dest.getDepth();
		int source_size = source_prices.length;
		int projected_dest_size = source_start_level+source_prices.length;
		
		if (dest_size < source_start_level) {
			update_max_orderbook_depth_after_insert(projected_dest_size-1);		
		} else {
			if (dest_size < projected_dest_size) {
				// [OVERLAP+]APPEND				
				dest.reserve(projected_dest_size);
				update_max_orderbook_depth_after_insert(projected_dest_size-1);		
				dest.m_depth = projected_dest_size;
				System.arraycopy (source_prices,	0, dest.m_prices,		source_start_level, source_size);	
				System.arraycopy (source_quantities,0, dest.m_quantities,	source_start_level, source_size);
			} else {
				// OVERLAP
				System.arraycopy (source_prices,	0, dest.m_prices,		source_start_level, source_size);	
				System.arraycopy (source_quantities,0, dest.m_quantities,	source_start_level, source_size);
				if (is_full && (dest_size > projected_dest_size)) {
					dest.m_depth = projected_dest_size;			// strip obsolete data				
				}
			}
		}																		
	}
	
	
	private final void update_max_orderbook_depth_after_insert (int last_insert_level)
	{
		if (last_insert_level > m_max_orderbook_depth) {
			m_max_orderbook_depth=1+last_insert_level;
		}
	}

	private final void check_orderbook_overflow_after_insert (OrderBookSide side, int last_insert_level)
	{
		if (side.getDepth() > m_max_orderbook_depth) {
			update_max_orderbook_depth_after_insert (last_insert_level);
			side.m_depth = m_max_orderbook_depth;
		}
	}	

	
	/**
	 * notif processing: "orderbook delta refresh"
	 * 
	 * 
	 */
	public synchronized void update_with_OrderBookDeltaRefresh 
							(	
									long timestamp,
									int ob_delta_action,
									int level,
									double price,
									double qty
							)
	{
		m_orderbook.setLastUpdateTimestamp(timestamp);
		
		switch (ob_delta_action) {
		case Constants.OrderBookDeltaAction_AskClearFromLevel:	internal_update_orderbook_delta_ClearFromLevel(m_orderbook.getAskSide(),level);		break;
		case Constants.OrderBookDeltaAction_BidClearFromLevel:	internal_update_orderbook_delta_ClearFromLevel(m_orderbook.getBidSide(),level);		break;
		case Constants.OrderBookDeltaAction_ALLClearFromLevel:	internal_update_orderbook_delta_ClearFromLevel(m_orderbook.getAskSide(),level);
																internal_update_orderbook_delta_ClearFromLevel(m_orderbook.getBidSide(),level);		break;
		case Constants.OrderBookDeltaAction_AskInsertAtLevel:		internal_update_orderbook_delta_InsertAtLevel	(m_orderbook.getAskSide(),level,price,qty);	break;
		case Constants.OrderBookDeltaAction_BidInsertAtLevel:		internal_update_orderbook_delta_InsertAtLevel	(m_orderbook.getBidSide(),level,price,qty);	break;
		case Constants.OrderBookDeltaAction_AskRemoveLevel:			internal_update_orderbook_delta_RemoveLevel 	(m_orderbook.getAskSide(),level,price,qty);	break;
		case Constants.OrderBookDeltaAction_BidRemoveLevel:			internal_update_orderbook_delta_RemoveLevel 	(m_orderbook.getBidSide(),level,price,qty);	break;
		case Constants.OrderBookDeltaAction_AskChangeQtyAtLevel:	internal_update_orderbook_delta_ChangeQtyAtLevel(m_orderbook.getAskSide(),level,qty);	break;
		case Constants.OrderBookDeltaAction_BidChangeQtyAtLevel:	internal_update_orderbook_delta_ChangeQtyAtLevel(m_orderbook.getBidSide(),level,qty);	break;
		default:
//			 DEBUG
			if (PDU.TRACE_CRITICAL_ENABLED) PDU.TRACE("InstrumentQuotationData::update_with_OrderBookDeltaRefresh() unexpected action=" + ob_delta_action);
		}
	}

	private final void internal_update_orderbook_delta_ClearFromLevel (OrderBookSide dest, int level)
	{							
		dest.m_depth = level;	
	}

	private final void internal_update_orderbook_delta_InsertAtLevel(OrderBookSide dest, int level, double price, double qty)
	{
		int current_depth = dest.getDepth();
		if (current_depth < level) {
			// BEYOND CURRENT DATA
			System.out.println("internal_update_orderbook_delta_InsertAtLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);			
			return;
		}
		dest.reserve(current_depth+1);
		for (int i=current_depth; i>level; --i) {
			dest.m_prices[i]=dest.m_prices[i-1];
			dest.m_quantities[i]=dest.m_quantities[i-1];
		}

		dest.m_prices[level]		= price;
		dest.m_quantities[level]	= qty;
		dest.m_depth = current_depth+1;
		check_orderbook_overflow_after_insert(dest, level);
	}

	private final void internal_update_orderbook_delta_RemoveLevel (OrderBookSide dest, int level, double price, double qty)
	{
		int current_depth = dest.getDepth();
		if (current_depth <= level) {
			System.out.println("internal_update_orderbook_delta_RemoveLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);
			return;
		}
		for (int i=level; i<current_depth-1; ++i) {
			dest.m_prices[i]	 = dest.m_prices[i+1];
			dest.m_quantities[i] = dest.m_quantities[i+1];
		}
		if (qty != 0) {	
			// *** new behaviour since API v3200 : if qty is not null then (price*qty) is the "new worst limit", to be appended.
			dest.m_prices[current_depth-1]		=price;
			dest.m_quantities[current_depth-1]	=qty;			
		} else {
			dest.m_depth = current_depth-1;
		}
	}

	private final void internal_update_orderbook_delta_ChangeQtyAtLevel (OrderBookSide dest, int level, double qty)
	{
		int current_depth = dest.getDepth();
		if (current_depth <= level) {
			System.out.println("internal_update_orderbook_delta_ChangeQtyAtLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);
			return;
		}
		dest.m_quantities[level] = qty;
	}
	
}
