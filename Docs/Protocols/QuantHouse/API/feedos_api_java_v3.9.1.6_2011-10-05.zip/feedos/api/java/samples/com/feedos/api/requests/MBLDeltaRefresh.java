package com.feedos.api.requests;

/*
 * (c) Copyright 2010 QuantHouse
 * All Rights Reserved.
 */

/**
 * MarketByLimit Delta Refresh event data
 * A delta refresh concerns a single layer and a single instrument. 
 */
public class MBLDeltaRefresh
{
	private final int m_InstrCode;
	private final int m_LayerId;
	private final UTCTimestamps m_Timestamps;
	private final int m_OrderBookDeltaAction;
	private final int m_Level;
	private final double m_Price;
	private final int m_CumulatedUnits;
	private final int m_NbOrders;
	private final boolean m_ContinuationFlag;
	private final ListOfTagValue m_OtherValues;
	
	/**
	 * MBLDeltaRefresh constructor
	 * 
	 * @param instrumentCode		instrument internal code
	 * @param layerId				identifier for this layer (0 stands for the default layer)
	 * @param timestamps			timestamps for the current delta @see UTCTimestamps
	 * @param orderBookDeltaAction	delta Action @see Constants.OrderBookDeltaAction_ALLClearFromLevel
	 * @param level					level of impact in the MarketByLimit
	 * @param price					price data when relevant
	 * @param cumulatedUnits		cumulated units data when relevant
	 * @param nbOrders				nb_orders data when relevant
	 * @param continuationFlag      continuation flag (tells if more DeltaRefresh are coming)
	 * @param otherValues			other Values @see ListOfTagValue 
	 */
	public MBLDeltaRefresh(int instrumentCode,
					int layerId, 
					UTCTimestamps timestamps,
					int orderBookDeltaAction, 
					int level,
					double price,
					int cumulatedUnits,
					int nbOrders,
					boolean continuationFlag,
					ListOfTagValue otherValues)
	{
		m_InstrCode = instrumentCode;
		m_LayerId = layerId;
		m_Timestamps = timestamps;
		m_OrderBookDeltaAction = orderBookDeltaAction;
		m_Level = level;
		m_Price = price;
		m_CumulatedUnits = cumulatedUnits;
		m_NbOrders = nbOrders;
		m_OtherValues = otherValues;
		m_ContinuationFlag = continuationFlag;
	}

	public final int getCode()					{ return m_InstrCode;	}
	public final int getLayerId() 				{ return m_LayerId; 	}
	public final UTCTimestamps getTimestamps() 	{ return m_Timestamps; 	}
	public final int getAction() 				{ return m_OrderBookDeltaAction;}
	public final int getLevel()					{ return m_Level;		} 
	public final double getPrice()				{ return m_Price;		}
	public final int getCumulatedUnits()		{ return m_CumulatedUnits;}	
	public final int getNbOrders()				{ return m_NbOrders;	}
	public final boolean getContinuationFlag()  { return m_ContinuationFlag; }
	public final ListOfTagValue getOtherValues(){ return m_OtherValues;	}
	
	@Override
	public String toString( )
	{
		return ""; // TODO
	}
	
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof MBLDeltaRefresh) ) return false;
		MBLDeltaRefresh that = (MBLDeltaRefresh)aThat;
		boolean common = (this.m_InstrCode == that.m_InstrCode) && 
						(this.m_LayerId == that.m_LayerId) &&
						(this.m_Timestamps.equals(that.m_Timestamps)) &&
						(this.m_OrderBookDeltaAction == that.m_OrderBookDeltaAction) &&
						(this.m_Level == that.m_Level) &&
						(Double.doubleToLongBits(this.m_Price) == Double.doubleToLongBits(that.m_Price)) &&
						(this.m_CumulatedUnits == that.m_CumulatedUnits) &&
						(this.m_NbOrders == that.m_NbOrders) &&
						(this.m_ContinuationFlag == that.m_ContinuationFlag);
		boolean otherValuesEquals = 
				((null == this.m_OtherValues && null == that.m_OtherValues) ||  ((null != this.m_OtherValues && null != that.m_OtherValues) && (this.m_OtherValues.equals(that.m_OtherValues))));	
		return common && otherValuesEquals;
	}
}
