package com.feedos.api.requests;

import com.feedos.api.core.Any;
import com.feedos.api.core.PDU;

/*
 * (c) Copyright 2010 QuantHouse
 * All Rights Reserved.
 */

/**
 * Layer data of the MBL (MarketByLimit)  
 * 
 * A layer owns a maximum visible depth member (actual depth of the MBL),
 * a couple of UTC Timestamp (storing the last update event time),
 * a bid and an ask @see OrderBookSide,
 * and finally a @see ListOfTagValue otherValues.
 */
public class MBLLayer
{
	private final int m_LayerId;
	private int m_MaxVisibleDepth;
	private UTCTimestamps m_Timestamps;
	private OrderBookSide m_BidLimits;
	private OrderBookSide m_AskLimits;
	private ListOfTagValue m_OtherValues;
	
	/**
	 * MBLLayer constructor
	 * 
	 * @param layerId			identifier for this layer (0 stands for the default one)
	 * @param maxVisibleDepth	stores the depth of the MBL (upper value of bid and ask side), may be negative for unlimited books
	 * @param timestamps		timestamps for the current layer @see UTCTimestamps
	 * @param bid				bidLimits @see OrderBookSide
	 * @param ask				askLimits @see OrderBookSide
	 * @param otherValues		otherValues @see ListOfTagValue
	 */
	public MBLLayer(int layerId, 
					int maxVisibleDepth, 
					UTCTimestamps timestamps,
					OrderBookSide bid, 
					OrderBookSide ask,
					ListOfTagValue otherValues)
	{
		m_LayerId = layerId;
		m_MaxVisibleDepth = maxVisibleDepth;
		m_Timestamps = timestamps;
		m_BidLimits = bid;
		m_AskLimits = ask;
		m_OtherValues = otherValues;
	}

	public final int getLayerId() 				{ return m_LayerId; 	}
	public final int getMaxVisibleDepth() 		{ return m_MaxVisibleDepth;	}
	public final UTCTimestamps getTimestamps() 	{ return m_Timestamps; 	}
	/**
	 * Get the bid limits that may be null
	 * @return @see OrderBookdSide
	 */
	public final OrderBookSide getBidLimits() 	{ if (null == m_BidLimits) { m_BidLimits = new OrderBookSide(); } return m_BidLimits; 	}
	
	/**
	 * Get the ask limits that may be null
	 * @return @see OrderBookdSide
	 */	
	public final OrderBookSide getAskLimits()	{  if (null == m_AskLimits) { m_AskLimits = new OrderBookSide(); } return m_AskLimits;	} 
	/**
	 * Get other values, may be null
	 * @return @see ListOfTagValue
	 */
	public final ListOfTagValue getOtherValues(){ return m_OtherValues;	}
	
	private final void update_OtherValues(ListOfTagValue inOtherValues)
	{
		if (null != inOtherValues)
		{
			int inTagNumber = inOtherValues.getNbTag();
			for (int i = 0; i < inTagNumber; i++)
			{
				Any otherValue = inOtherValues.getTagByIndex(i);
				if (otherValue.getSyntax() != Any.SYNTAX_UNKNOWN)
				{
					m_OtherValues.addTag(inOtherValues.getTagNumberByIndex(i), otherValue);
				}
				else
				{
					m_OtherValues.removeTagByNumber(inOtherValues.getTagNumberByIndex(i));
				}
			}
		}
	}
	
	public final void update_with_MBLOverlapRefresh(MBLOverlapRefresh overlap)
	{
		m_Timestamps = overlap.getTimestamps();
		
		internal_update_orderbook_refresh_one_side (
				overlap.getBidChangeIndicator(), 
				overlap.getBidLimits(),
				getBidLimits());
		internal_update_orderbook_refresh_one_side (
				overlap.getAskChangeIndicator(), 
				overlap.getAskLimits(), 
				getAskLimits());		
		update_OtherValues(overlap.getOtherValues());
	}
	
	private final void internal_update_orderbook_refresh_one_side(
			int change_indicator,	
			OrderBookSide source,
			OrderBookSide dest)
	{
		boolean is_full;
		int source_start_level;
		if (change_indicator < 0) {
			is_full=true;
			source_start_level=-change_indicator-1;
		} else {
			is_full=false;
			source_start_level=change_indicator;
		}
		
		int dest_size = dest.getDepth();
		int source_size = (null != source) ? source.getDepth() : 0;
		int projected_dest_size = source_start_level+source_size;
		
		if (null == source)
		{
			if (is_full && (dest_size > projected_dest_size)) {
				dest.m_depth = projected_dest_size;			// strip obsolete data				
			}	
			return;
		}
		
		if (dest_size < source_start_level) {
			update_max_orderbook_depth_after_insert(projected_dest_size-1);		
		} else {
			if (dest_size < projected_dest_size) {
				// [OVERLAP+]APPEND				
				dest.reserve(projected_dest_size);
				update_max_orderbook_depth_after_insert(projected_dest_size-1);		
				dest.m_depth = projected_dest_size;
				System.arraycopy (source.m_prices,		0, dest.m_prices,		source_start_level, source_size);	
				System.arraycopy (source.m_quantities,	0, dest.m_quantities,	source_start_level, source_size);
				System.arraycopy (source.m_nborders,	0, dest.m_nborders,		source_start_level, source_size);				
			} else {
				// OVERLAP
				System.arraycopy (source.m_prices,	0, dest.m_prices,		source_start_level, source_size);	
				System.arraycopy (source.m_quantities,0, dest.m_quantities,	source_start_level, source_size);
				System.arraycopy (source.m_nborders,	0, dest.m_nborders,	source_start_level, source_size);						
				if (is_full && (dest_size > projected_dest_size)) {
					dest.m_depth = projected_dest_size;			// strip obsolete data				
				}
			}
		}																		
	}
	
	private final void update_max_orderbook_depth_after_insert (int last_insert_level)
	{
		if (last_insert_level > m_MaxVisibleDepth) {
			m_MaxVisibleDepth=1+last_insert_level;
		}
	}
	
	public final void update_with_MBLDeltaRefresh(MBLDeltaRefresh delta)
	{
		m_Timestamps = delta.getTimestamps();
		
		switch (delta.getAction()) 
		{
		case Constants.OrderBookDeltaAction_AskClearFromLevel:	internal_update_orderbook_delta_ClearFromLevel(getAskLimits(),delta.getLevel());		break;
		case Constants.OrderBookDeltaAction_BidClearFromLevel:	internal_update_orderbook_delta_ClearFromLevel(getBidLimits(),delta.getLevel());		break;
		case Constants.OrderBookDeltaAction_ALLClearFromLevel:	internal_update_orderbook_delta_ClearFromLevel(getAskLimits(),delta.getLevel());
																internal_update_orderbook_delta_ClearFromLevel(getBidLimits(),delta.getLevel());		break;
		case Constants.OrderBookDeltaAction_AskInsertAtLevel:	internal_update_orderbook_delta_InsertAtLevel	(getAskLimits(),delta.getLevel(),delta.getPrice(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_BidInsertAtLevel:	internal_update_orderbook_delta_InsertAtLevel	(getBidLimits(),delta.getLevel(),delta.getPrice(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_AskRemoveLevelAndAppend: 
																internal_update_orderbook_delta_RemoveLevelAndAppend 	(getAskLimits(),delta.getLevel(),delta.getPrice(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_AskRemoveLevel:		internal_update_orderbook_delta_RemoveLevel 	(getAskLimits(),delta.getLevel(),delta.getPrice(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_BidRemoveLevelAndAppend: 
																internal_update_orderbook_delta_RemoveLevelAndAppend 	(getBidLimits(),delta.getLevel(),delta.getPrice(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_BidRemoveLevel:		internal_update_orderbook_delta_RemoveLevel 	(getBidLimits(),delta.getLevel(),delta.getPrice(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_AskChangeQtyAtLevel:internal_update_orderbook_delta_ChangeQtyAtLevel(getAskLimits(),delta.getLevel(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		case Constants.OrderBookDeltaAction_BidChangeQtyAtLevel:internal_update_orderbook_delta_ChangeQtyAtLevel(getBidLimits(),delta.getLevel(),delta.getCumulatedUnits(),delta.getNbOrders());	break;
		default:
//			 DEBUG
			if (PDU.TRACE_CRITICAL_ENABLED) PDU.TRACE("MBLLayer::update_with_OrderBookDeltaRefresh() unexpected action=" + delta.getAction());
		}		
		update_OtherValues(delta.getOtherValues());
	}
	
	private final void internal_update_orderbook_delta_ClearFromLevel (OrderBookSide dest, int level)
	{							
		dest.m_depth = level;	
	}

	private final void internal_update_orderbook_delta_InsertAtLevel(OrderBookSide dest, int level, double price, int qty, int nb_orders)
	{
		int current_depth = dest.getDepth();
		if (current_depth < level) {
			// BEYOND CURRENT DATA
			System.out.println("internal_update_orderbook_delta_InsertAtLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);			
			return;
		}
		// Shift limits down one level
		dest.reserve(current_depth+1);
		for (int i=current_depth; i>level; --i) {
			dest.m_prices[i]	= dest.m_prices[i-1];
			dest.m_quantities[i]= dest.m_quantities[i-1];
			dest.m_nborders[i]	= dest.m_nborders[i-1];			
		}

		dest.m_prices[level]		= price;
		dest.m_quantities[level]	= qty;
		dest.m_nborders[level]		= nb_orders;
		dest.m_depth 				= current_depth+1;
		check_orderbook_overflow_after_insert(dest, level);
	}

	private final void internal_update_orderbook_delta_RemoveLevel (OrderBookSide dest, int level, double price, int qty, int nb_orders)
	{
		int current_depth = dest.getDepth();
		if (current_depth <= level) {
			System.out.println("internal_update_orderbook_delta_RemoveLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);
			return;
		}
		for (int i=level; i<current_depth-1; ++i) {
			dest.m_prices[i]=dest.m_prices[i+1];
			dest.m_quantities[i]=dest.m_quantities[i+1];
			dest.m_nborders[i]=dest.m_nborders[i+1];						
		}
		dest.m_depth = current_depth-1;
	}
	
	// new behaviour since API v3.8.8.7 : Remove level then append limit (price * qty @ nb_orders) is the "new worst limit", to be appended.
	private final void internal_update_orderbook_delta_RemoveLevelAndAppend (OrderBookSide dest, int level, double price, int qty, int nb_orders)
	{
		int current_depth = dest.getDepth();
		if (current_depth <= level) {
			System.out.println("internal_update_orderbook_delta_RemoveLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);
			return;
		}
		for (int i=level; i<current_depth-1; ++i) {
			dest.m_prices[i]=dest.m_prices[i+1];
			dest.m_quantities[i]=dest.m_quantities[i+1];
			dest.m_nborders[i]=dest.m_nborders[i+1];						
		}
		dest.m_prices[current_depth-1]		=price;
		dest.m_quantities[current_depth-1]	=qty;	
		dest.m_nborders[current_depth-1]	=nb_orders;			
	}	
	
	private final void internal_update_orderbook_delta_ChangeQtyAtLevel (OrderBookSide dest, int level, int qty, int nb_orders)
	{
		int current_depth = dest.getDepth();
		if (current_depth <= level) {
			System.out.println("internal_update_orderbook_delta_ChangeQtyAtLevel:: caution: current_depth <= level on level="+level+" qty="+qty+" current_depth="+current_depth);
			return;
		}
		dest.m_quantities[level] 	= qty;
		dest.m_nborders[level] 		= nb_orders;		
	}
	
	private final void check_orderbook_overflow_after_insert (OrderBookSide side, int last_insert_level)
	{
		if (side.getDepth() > m_MaxVisibleDepth) {
			update_max_orderbook_depth_after_insert (last_insert_level);
			side.m_depth = m_MaxVisibleDepth;
		}
	}	
	
	public final void update_with_MBLMaxVisibleDepth(MBLMaxVisibleDepth depth)
	{
		m_MaxVisibleDepth = depth.getMaxVisibleDepth();
		if (null != getBidLimits())
		{
			getBidLimits().setDepth(depth.getMaxVisibleDepth());
		}
		if (null != getAskLimits())
		{
			getAskLimits().setDepth(depth.getMaxVisibleDepth());
		}
	}
	
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof MBLLayer) ) return false;
		MBLLayer that = (MBLLayer)aThat;
		boolean common = (this.m_LayerId == that.m_LayerId) &&
						(this.m_Timestamps.equals(that.m_Timestamps)) &&
						(this.m_MaxVisibleDepth == that.m_MaxVisibleDepth);	
		boolean bidEquals = (null == this.m_BidLimits && null == that.m_BidLimits) || (null != this.m_BidLimits && null != that.m_BidLimits && this.m_BidLimits.equals(that.m_BidLimits));
		boolean askEquals = (null == this.m_AskLimits && null == that.m_AskLimits) || (null != this.m_AskLimits && null != that.m_AskLimits && this.m_AskLimits.equals(that.m_AskLimits));
		boolean otherValuesEquals = (null == this.m_OtherValues && null == that.m_OtherValues) || (null != this.m_OtherValues && null != that.m_OtherValues && this.m_OtherValues.equals(that.m_OtherValues));
		return 	 common && bidEquals && askEquals && otherValuesEquals;
	}
}
