package com.feedos.api.requests;

/*
 * (c) Copyright 2010 QuantHouse
 * All Rights Reserved.
 */

/**
 * Event data specifying MBL (MarketByLimit) depth modification for a single layer.
 */
public class MBLMaxVisibleDepth
{
	private final int m_InstrCode;
	private final int m_LayerId;
	private final int m_MaxVisibleDepth;
	
	/**
	 * MBLMaxVisibleDepth constructor
	 * 
	 * @param instrumentCode		instrument code
	 * @param layerId				identifier ot the relevant layer (0 stands for the default one)
	 * @param maxVisibleDepth		maximum depth of the MarketByLimit to take into account.
	 */
	public MBLMaxVisibleDepth(int instrumentCode,
					int layerId, 
					int maxVisibleDepth)
	{
		m_InstrCode = instrumentCode;
		m_LayerId = layerId;
		m_MaxVisibleDepth = maxVisibleDepth;
	}

	public final int getCode()					{ return m_InstrCode;	}
	public final int getLayerId() 				{ return m_LayerId; 	}
	public final int getMaxVisibleDepth()		{ return m_MaxVisibleDepth;	} 
	
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof MBLMaxVisibleDepth) ) return false;
		MBLMaxVisibleDepth that = (MBLMaxVisibleDepth)aThat;
		return 	(this.m_InstrCode == that.m_InstrCode) && 
				(this.m_LayerId == that.m_LayerId) && 
				(this.m_MaxVisibleDepth == that.m_MaxVisibleDepth);
	}
}
