package com.feedos.api.requests;


/*
 * (c) Copyright 2010 QuantHouse
 * All Rights Reserved.
 */

/**
 * Event data for a single MBL (MarketByLimit) layer refresh.
 * 
 * BidChangeIndicator (resp. AskChangeIndicator) holds two informations: 
 * a - the start level of the impact 
 * b - the fact that the carried bidLimits (resp. askLimits) is complete (when the indicator is lower than -1).
 */
public class MBLOverlapRefresh
{
	private final int m_InstrCode;
	private final int m_LayerId;
	private final UTCTimestamps m_Timestamps;
	private final int m_BidChangeIndicator;
	private final int m_AskChangeIndicator;
	private final OrderBookSide m_BidLimits;
	private final OrderBookSide m_AskLimits;
	private final ListOfTagValue m_OtherValues;
	

	/**
	 * MBLOverlapRefresh constructor
	 * 
	 * @param instrumentCode		instrument code
	 * @param layerId				identifier ot the relevant layer (0 stands for the default one)
	 * @param timestamps			modification timestamps @see UTCTimestamps
	 * @param bidChangeIndicator	tells how to handle the BID entries		
	 * @param askChangeIndicator	tells how to handle the ASK entries		
	 * @param bidLimits				limits for the BID side @see OrderBookSide
	 * @param askLimits				limits for the ASK side @see OrderBookSide
	 * @param otherValues			Other values @see ListOfTagValue
	 */
	public MBLOverlapRefresh(int instrumentCode,
					int layerId, 
					UTCTimestamps timestamps,
					int bidChangeIndicator, 
					int askChangeIndicator,
					OrderBookSide bidLimits,
					OrderBookSide askLimits,
					ListOfTagValue otherValues)
	{
		m_InstrCode = instrumentCode;
		m_LayerId = layerId;
		m_Timestamps = timestamps;
		m_BidChangeIndicator = bidChangeIndicator;
		m_AskChangeIndicator = askChangeIndicator;
		m_BidLimits = bidLimits;
		m_AskLimits = askLimits;
		m_OtherValues = otherValues;
	}

	public final int getCode()					{ return m_InstrCode;	}
	public final int getLayerId() 				{ return m_LayerId; 	}
	public final UTCTimestamps getTimestamps() 	{ return m_Timestamps; 	}
	public final int getBidChangeIndicator() 	{ return m_BidChangeIndicator; }
	public final int getAskChangeIndicator()	{ return m_AskChangeIndicator;	} 
	public final OrderBookSide getBidLimits()	{ return m_BidLimits;	}
	public final OrderBookSide getAskLimits()	{ return m_AskLimits;	}	
	public final ListOfTagValue getOtherValues(){ return m_OtherValues;	}		
		
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof MBLOverlapRefresh) ) return false;
		MBLOverlapRefresh that = (MBLOverlapRefresh)aThat;
		boolean common = (this.m_InstrCode == that.m_InstrCode) && 
		(this.m_LayerId == that.m_LayerId) &&
		(this.m_Timestamps.equals(that.m_Timestamps)) &&
		(this.m_BidChangeIndicator == that.m_BidChangeIndicator) &&
		(this.m_AskChangeIndicator == that.m_AskChangeIndicator);
		
		boolean nullBid = (null == this.m_BidLimits && null == that.m_BidLimits);
		boolean nullAsk = (null == this.m_AskLimits && null == that.m_AskLimits);
		boolean nullOtherValues = (null == this.m_OtherValues && null == that.m_OtherValues);

		boolean bidEquals = (null != this.m_BidLimits && null != that.m_BidLimits && this.m_BidLimits.equals(that.m_BidLimits));
		boolean askEquals = (null != this.m_AskLimits && null != that.m_AskLimits && this.m_AskLimits.equals(that.m_AskLimits));
		boolean otherValuesEquals = (null != this.m_OtherValues && null != that.m_OtherValues && this.m_OtherValues.equals(that.m_OtherValues));	
		return (common 
				&& (bidEquals || nullBid) 
				&& (askEquals || nullAsk) 
				&& (otherValuesEquals || nullOtherValues));
	}
}
