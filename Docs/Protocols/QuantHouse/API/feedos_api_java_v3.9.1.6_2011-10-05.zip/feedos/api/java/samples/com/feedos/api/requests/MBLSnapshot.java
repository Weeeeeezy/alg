package com.feedos.api.requests;

import java.util.Vector;

/*
 * (c) Copyright 2010 QuantHouse
 * All Rights Reserved.
 * 
 * @author Prodhomme
 */

/**
 * Snapshot values for MarketByLimit of an instrument
 * 
 * A snapshot is a collection of MBLLayers identified by a LayerId. 
 */
public class MBLSnapshot 
{
	private final int m_Instr;
	private Vector<MBLLayer> m_Layers;
	
	/**
	 * MBLSnapshot constructor
	 * 
	 * @param instrumentCode	instrument code 
	 * @param layers			layers @see MBLLayer
	 */
	public MBLSnapshot(int instrumentCode,
						MBLLayer[] layers)
	{
		m_Instr = instrumentCode;
		if (null != layers && 0 < layers.length)
		{
			m_Layers = new Vector<MBLLayer>(layers.length,1);
			for (int i = 0; i< layers.length; i++)
			{
				if (null != layers[i]) m_Layers.add(layers[i]);
			}
		}
		else
		{
			m_Layers = null;	
		}
	}
	
	public final int getCode() 			{ return m_Instr; 	}
	public final Vector<MBLLayer> getLayers() 		{ return m_Layers;	}

	private final MBLLayer getLayerWithId(int layerId)
	{
		if (null != m_Layers)
		{
			for (int i = 0; i < m_Layers.size();i++)
			{
				MBLLayer layer = m_Layers.elementAt(i);
				if (layerId == layer.getLayerId())
				{
					return layer;
				}
			}
		}
		else
		{
			m_Layers = new Vector<MBLLayer>(1,1);
		}
		MBLLayer layer = new MBLLayer(layerId,65535,new UTCTimestamps(0,0),null,null,null);
		m_Layers.add(layer);
		return layer;
	}
	
	/**
	 * Update a MBLSnapshot with an incoming overlap refresh event(one single layer impacted)
	 * @param overlap @see MBLOverlapRefresh
	 * @return @see MBLLayer, the impacted layer
	 */
	public final MBLLayer update_with_MBLOverlapRefresh(MBLOverlapRefresh overlap)
	{	
		MBLLayer layer = getLayerWithId(overlap.getLayerId());
		if (null != layer)
		{
			layer.update_with_MBLOverlapRefresh(overlap);
		}
		return layer;
	}	
	
	/**
	 * Update a MBLSnapshot with an incoming delta refresh event
	 * 
	 * @param delta	@see MBLDeltaRefresh
	 * @return @see MBLLayer, the impacted layer
	 */
	public final MBLLayer update_with_MBLDeltaRefresh(MBLDeltaRefresh delta)
	{	
		MBLLayer layer = getLayerWithId(delta.getLayerId());
		if (null != layer)
		{
			layer.update_with_MBLDeltaRefresh(delta);
		}
		return layer;
	}
	
	/**
	 * Update a MBLSnapshot with an incoming maxVisibleDepth event
	 * @param depth @see MBLMaxVisibleDepth
	 * @return @see MBLLayer, the impacted layer
	 */
	public final MBLLayer update_with_MBLMaxVisibleDepth(MBLMaxVisibleDepth depth)
	{	
		MBLLayer layer = getLayerWithId(depth.getLayerId());
		if (null != layer)
		{
			layer.update_with_MBLMaxVisibleDepth(depth);
		}
		return layer;
	}	
	
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof MBLSnapshot) ) return false;
		MBLSnapshot that = (MBLSnapshot)aThat;
		return 	(this.m_Instr == that.m_Instr) && 
				(this.m_Layers.equals(that.m_Layers));
		
	}
}
