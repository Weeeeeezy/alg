package com.feedos.api.requests;


/*
 * (c) Copyright 2007 QuantHouse
 * All Rights Reserved.
 * 
 * @author Dicharry
 */
 
/**
 *  container class for a "Market Sheet Entry" 
 * 
 */ 

public class MarketSheetEntry {
	
	String m_id;
	double m_price;
	double m_quantity;
	ListOfTagValue m_quotationcontextflags;
	
	/** 
	 * @return the id 
	 */
	public final String	getId	() { return m_id; }
	
	/** 
	 * @return the price
	 */
	public final double	getPrice	() { return m_price; }

	/** 
	 * @return the quantity
	 */
	public final double	getQty		() { return m_quantity; }

	/** 
	 * @return the QuotationContextFlags
	 */
	public final ListOfTagValue	getQuotationContextFlags		() { return m_quotationcontextflags; }
	
	/**
	 * @param id
	 */
	
	public final void setId (String id)
	{
		m_id = id;
	}
	
	/**
	 * @param price
	 */
	
	public final void setPrice (double price) 
	{
		m_price = price;
	}
	
	/**
	 * @param quantity
	 */
	
	public final void setQuantity (double quantity)
	{
		m_quantity = quantity;
	}

	/**
	 * @param quotationcontextflags
	 */
	
	public final void setQuotationContextFlags (ListOfTagValue quotationcontextflags)
	{
		m_quotationcontextflags = quotationcontextflags;
	}
	
	public MarketSheetEntry()
	{
		
	}

	public MarketSheetEntry(String id, double price, double quantity, ListOfTagValue quotationcontextflags)
	{
		m_id = id;
		m_price = price;
		m_quantity = quantity;
		
		m_quotationcontextflags = quotationcontextflags;
	}

	public MarketSheetEntry(String id, double price, double quantity)
	{
		m_id = id;
		m_price = price;
		m_quantity = quantity;

	}
	
}