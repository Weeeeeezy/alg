package com.feedos.api.requests;

import java.util.Vector;

/*
 * (c) Copyright 2007 QuantHouse
 * All Rights Reserved.
 * 
 * @author Dicharry
 */
 
/**
 *  container class for an "market sheet" (timestamp + ASK lines + BID lines)
 * 
 */ 

public class MarketSheetVector 
{
	Vector<MarketSheetEntry> m_buy_side;
	Vector<MarketSheetEntry> m_sell_side;
	
	public final Vector<MarketSheetEntry> getBuySide()
	{
		return m_buy_side;
	}
	
	public final Vector<MarketSheetEntry> getSellSide()
	{
		return m_sell_side;
	}
/**
 * 
 * @param FIXSide
 * @param entry
 */
	public final void addEntry (char FIXSide, MarketSheetEntry entry)
	{
		if(FIXSide == '1')
		{
			addBuyEntry(entry);
		} 
		else if(FIXSide == '2')
		{
			addSellEntry(entry);
		}
		
	}
	
	public final void addBuyEntry (MarketSheetEntry entry)
	{
		m_buy_side.addElement(entry);
	}
	
	public final void addSellEntry (MarketSheetEntry entry)
	{
		m_sell_side.addElement(entry);
	}

/**
 * 
 * @param FIXSide
 * @param entry
 */
	
	public final void addEntryAt (char FIXSide, MarketSheetEntry entry, int position)
	{
		if(FIXSide == '1')
		{
			addBuyEntryAt(entry, position);
		} 
		else if(FIXSide == '2')
		{
			addSellEntryAt(entry, position);
		}
		
	}
	
	public final void addBuyEntryAt (MarketSheetEntry entry, int position)
	{
		m_buy_side.add(position, entry);
	}
	
	public final void addSellEntryAt (MarketSheetEntry entry, int position)
	{
		m_sell_side.add(position, entry);
	}
	
/**
 * 
 * @param FIXSide
 * @param position
 */
	
	public final MarketSheetEntry getEntry (char FIXSide, int position)
	{
		if(FIXSide == '1')
		{
			return getBuyEntry(position);
		} 
		else if(FIXSide == '2')
		{
			return getSellEntry(position);
		}
		
		return new MarketSheetEntry();
	}

	public final MarketSheetEntry getBuyEntry (int position)
	{
		return (MarketSheetEntry) m_buy_side.elementAt(position);
	}
	
	public final MarketSheetEntry getSellEntry (int position)
	{
		return (MarketSheetEntry) m_sell_side.elementAt(position);
	}

	
/**
 * 
 * @param FIXSide
 * @param entry
 * @param old_level
 * @param new_level
 */
	
	public final void modifyOrderEntry (char FIXSide, MarketSheetEntry entry, int old_level, int new_level)
	{
		if(FIXSide == '1')
		{
			modifyBuyOrderEntry( entry, old_level, new_level);
		} 
		else if(FIXSide == '2')
		{
			modifySellOrderEntry( entry, old_level, new_level);
		}	
	}
	
	public final void modifyBuyOrderEntry (MarketSheetEntry modified_entry, int old_level, int new_level)
	{
		m_buy_side.remove(old_level);
		m_buy_side.insertElementAt(modified_entry, new_level);
	}
	
	public final void modifySellOrderEntry (MarketSheetEntry modified_entry, int old_level, int new_level)
	{
		m_sell_side.remove(old_level);
		m_sell_side.insertElementAt(modified_entry, new_level);
	}

/**
 * 
 * @param FIXSide
 * @param order_id
 * @param level
 */
	
	public final void removeEntry (char FIXSide, String order_id, int level)
	{
		if(FIXSide == '1')
		{
			removeBuyEntry(order_id, level);
		} 
		else if(FIXSide == '2')
		{
			removeSellEntry(order_id, level);
		}	
	}
	
	public final void removeBuyEntry (String order_id, int level)
	{
		if( ((MarketSheetEntry)m_buy_side.elementAt(level)).getId().equals(order_id) )
		{
			m_buy_side.remove(level);
		}
	}
	
	public final void removeSellEntry (String order_id, int level)
	{
		if( ((MarketSheetEntry)m_sell_side.elementAt(level)).getId().equals(order_id) )
		{
			m_sell_side.remove(level);
		}	
	}

/**
 * 
 * @param FIXSide
 * @param order_id
 * @param level
 */
	
	public final void removeAllPreviousEntry (char FIXSide, String order_id, int level)
	{
		if(FIXSide == '1')
		{
			removeAllPreviousBuyEntry(order_id, level);
		} 
		else if(FIXSide == '2')
		{
			removeAllPreviousSellEntry(order_id, level);
		}	
	}
	
	public final void removeAllPreviousBuyEntry (String order_id, int level)
	{
		if( ((MarketSheetEntry)m_buy_side.elementAt(level)).getId().equals(order_id) )
		{
			for(int i = 0; i < level; i++)
			{
				m_buy_side.remove(level);
			}
		}
	}
	
	public final void removeAllPreviousSellEntry (String order_id, int level)
	{
		if( ((MarketSheetEntry)m_sell_side.elementAt(level)).getId().equals(order_id) )
		{
			for(int i = 0; i < level; i++)
			{
				m_sell_side.remove(level);
			}
		}
	}
	
/**
 * 
 * @param FIXSide
 */
	
	public final void removeAllEntry (char FIXSide)
	{
		if(FIXSide == '1')
		{
			removeAllBuyEntry();
		} 
		else if(FIXSide == '2')
		{
			removeAllSellEntry();
		}	
	}
	
	public final void removeAllBuyEntry ()
	{
		m_buy_side.clear();
	}
	
	public final void removeAllSellEntry ()
	{
		m_sell_side.clear();
	}	
	
/**
 * 
 */
	
	public MarketSheetVector()
	{
	}
	
	public MarketSheetVector(Vector<MarketSheetEntry> bid_side, Vector<MarketSheetEntry> ask_side)
	{
		m_buy_side = bid_side;
		m_sell_side = ask_side;
	}	
}