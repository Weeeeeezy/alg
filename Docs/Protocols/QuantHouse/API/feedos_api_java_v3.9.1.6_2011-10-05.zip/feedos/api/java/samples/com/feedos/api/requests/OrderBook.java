package com.feedos.api.requests;

/*
 * (c) Copyright 2006 QuantHouse
 * All Rights Reserved.
 * 
 * @author fenouil
 */
 
/**
 *  container class for an "order book" (timestamp + ASK lines + BID lines)
 * 
 */ 
 
public class OrderBook {

	long m_last_update_timestamp;
	
	OrderBookSide	m_bid_side=new OrderBookSide();
	OrderBookSide	m_ask_side=new OrderBookSide();

	/** 
	 * accessor for BID (buy) side of the order book
	 */
	public final OrderBookSide	getBidSide() { return m_bid_side; } 
	
	/** 
	 * accessor for ASK (sell) side of the order book
	 */
	public final OrderBookSide	getAskSide() { return m_ask_side; } 
	
	/**
	 * get the timestamp
	 */
	public final long	getLastUpdateTimestamp() { return m_last_update_timestamp; }
	
	/**
	 * update the timestamp
	 */
	public final void	setLastUpdateTimestamp(long	t) { m_last_update_timestamp=t; }
	
	/**
	 * clear both sides & reset the last_update_timestamp
	 */
	public final void reset () { reset_limits(); m_last_update_timestamp=0; }
	
	/**
	 * clear both sides
	 */
	public final void reset_limits () { m_ask_side.clear(); m_bid_side.clear(); }
	
	/**
	 * set the maximum available depth
	 */
	public final void set_max_depth (int max_depth)
	{
		if (-1 == max_depth) {
			max_depth = 10;
		}
		m_bid_side.reserve(max_depth);
		m_ask_side.reserve(max_depth);		
		// TODO should strip existing data
	}

	public OrderBook () 
	{
	}

	public OrderBook (	long last_update_timestamp,
						OrderBookSide bid_side,
						OrderBookSide ask_side
						) 
	{
		m_last_update_timestamp = last_update_timestamp;
		m_bid_side=bid_side;
		m_ask_side=ask_side;
	}
	
}
