package com.feedos.api.requests;
import java.lang.Math;
import java.util.Arrays;

/*
 * (c) Copyright 2007 QuantHouse
 * All Rights Reserved.
 * 
 * @author fenouil
 */
 
/**
 *  container class for "half an order book"
 * 
 */ 
 public class OrderBookSide {

	int m_capacity = 5;
	int m_depth=0;
	
	double[] m_prices		=new double[m_capacity];
	double[] m_quantities	=new double[m_capacity];
	int[]	 m_nborders		=new int[m_capacity];
	
	void set_best_limit (double price, double qty)
	{
		if (qty==0) {
			clear ();
		} else {
			if (m_depth==0) 
				m_depth=1;
			m_prices[0]=price;
			m_quantities[0]=qty;
		}
	}
	
	/** 
	 * @return the number of <tt>price <b>x</b> qty</tt> lines
	 */
	public final int	getDepth() { return m_depth; } 
	public final void	setDepth(int depth) 
	{ 
		reserve(depth);
		m_depth = depth; 
	} 
	
	/** 
	 * @return the price at the given line (0 .. depth-1)
	 */
	public final double	getPrice	(int line_no) { return m_prices[line_no]; }

	/** 
	 * @return the quantity at the given line (0 .. depth-1)
	 */
	public final double	getQty		(int line_no) { return m_quantities[line_no]; }

	/** 
	 * @return the nb orders at the given line (0 .. depth-1)
	 */
	public final int getNbOrders		(int line_no) { return m_nborders[line_no]; }
	
	/**
	 * clear prices & quantities
	 */
	public final void clear () { m_depth=0; }

	/**
	 * increase capacity
	 */
	public final void reserve (int new_capacity)
	{
		if (new_capacity > m_capacity) {
			double[] new_prices		=new double[new_capacity];
			double[] new_quantities	=new double[new_capacity];
			int[] 	 new_nborders	=new int[new_capacity];
			System.arraycopy (m_prices,     0, new_prices,     0, m_depth);
			System.arraycopy (m_quantities, 0, new_quantities, 0, m_depth);	
			System.arraycopy (m_nborders, 0, new_nborders, 0, m_depth);	
			m_capacity   = new_capacity;
			m_prices     = new_prices;
			m_quantities = new_quantities;
			m_nborders   = new_nborders;
		}
	}
	
	/**
	 * load content
	 */
	public final void load (double[] prices, double[] quantities)
	{	
		int cur_depth = Math.min (prices.length, quantities.length);
		reserve (cur_depth);
		m_depth = cur_depth;
		System.arraycopy (prices,     0, m_prices,     0, m_depth);
		System.arraycopy (quantities, 0, m_quantities, 0, m_depth);
		Arrays.fill(m_nborders, -1);
	}

	/**
	 * load content
	 */
	public final void load (double[] prices, double[] quantities, int[] nborders)
	{	
		int cur_depth = Math.min (prices.length, quantities.length);
		reserve (cur_depth);
		m_depth = cur_depth;
		System.arraycopy (prices,     0, m_prices,     0, m_depth);
		System.arraycopy (quantities, 0, m_quantities, 0, m_depth);
		System.arraycopy (nborders,   0, m_nborders,   0, m_depth);
	}
	
	/**
	 * append a line. 
	 * 
	 * <em>No checking is done about the consistency</em>
	 */
	public final void appendEntry (double price, double quantity)
	{
		reserve (m_depth+1);
		m_prices[m_depth] = price;
		m_quantities[m_depth] = quantity;
		++m_depth;
	}
	
	/**
	 * append a line. 
	 * 
	 * <em>No checking is done about the consistency</em>
	 */
	public final void appendEntry (double price, double quantity, int nborders)
	{
		reserve (m_depth+1);
		m_prices[m_depth] = price;
		m_quantities[m_depth] = quantity;
		m_nborders[m_depth] = nborders;
		++m_depth;
	}
	
	public OrderBookSide (double[] prices, double[] quantities) 
	{
		load (prices, quantities);
	}

	public OrderBookSide (double[] prices, double[] quantities, int[] nborders) 
	{
		load (prices, quantities, nborders);
	}
	
	public OrderBookSide () 
	{
	}
	
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof OrderBookSide) ) return false;
		OrderBookSide that = (OrderBookSide)aThat;
		return (Arrays.equals(this.m_prices,that.m_prices) && 
				Arrays.equals(this.m_quantities,that.m_quantities) &&
				Arrays.equals(this.m_nborders,that.m_nborders));
		
	}
}
