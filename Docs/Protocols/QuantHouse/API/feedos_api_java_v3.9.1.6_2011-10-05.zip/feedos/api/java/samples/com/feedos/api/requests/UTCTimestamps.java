package com.feedos.api.requests;

/*
 * (c) Copyright 2010 QuantHouse
 * All Rights Reserved.
 */

public class UTCTimestamps
{
	private final long m_Server;
	private final long m_Market;
	
	/**
	 * UTCTimestamps constructor
	 * 
	 * @param serverUTCTimestamp	server UTC timestamp, expressed in microseconds.
	 * @param marketUTCTimestamp	market UTC timestamp, expressed in microseconds. 
	 */
	public UTCTimestamps(long serverUTCTimestamp,
						 long marketUTCTimestamp)
	{
		m_Server = serverUTCTimestamp;
		m_Market = marketUTCTimestamp;
	}

	public final long getServer()		{ return m_Server;	}
	public final long getMarket() 		{ return m_Market; 	}
	
	@Override
	public String toString ( )
	{
		return "";
	}	
	
	@Override
	public boolean equals(Object aThat)
	{
		if ( this == aThat ) return true;
		if ( !(aThat instanceof UTCTimestamps) ) return false;
		UTCTimestamps that = (UTCTimestamps)aThat;
		return (Double.doubleToLongBits(this.m_Server) == Double.doubleToLongBits(that.m_Server)) && 
				(Double.doubleToLongBits(this.m_Market) == Double.doubleToLongBits(that.m_Market));
		
	}
}
