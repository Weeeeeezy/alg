package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */
 

class MySubscribeInstrumentsReceiverFeedStatus implements 
Receiver_Connection_SubscribeToFeedStatus
{
	MySubscribeInstrumentsReceiverFeedStatus (  )
	{
	}

	public void connectionSubscribeToFeedStatusResponse( FeedStatus[] FullSnapshot )
	{
		System.out.println("connectionSubscribeToFeedStatusResponse...");
		for(int i = 0; i < FullSnapshot.length; i++)
		{
			DumpFunctions.dump(FullSnapshot[i]);
		}
	}
	
	public void connectionSubscribeToFeedStatusUnsubNotif(int subscription_num,
			Object user_context,
			int rc)
	{
		System.out.println("connectionSubscribeToFeedStatusUnsubNotif...");
		
	}
	
	public void connectionNotifFeedStatusEvent (	
			String Sender,
			long SenderUTCTimestamp,
			FeedStatusEvent Event
	)
	{
		System.out.println("connectionNotifFeedStatusEvent from "+Sender);		
		DumpFunctions.dump(Event);
	}
	
	public void connectionNotifFeedStatusUpdate (	
			String Sender,
			long SenderUTCTimestamp,
			FeedStatus Status
	)
	{
		System.out.println("connectionNotifFeedStatusUpdate from "+Sender);		
		DumpFunctions.dump(Status);
	}
}

public class ASyncConnectionSubFeedStatus {
			
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("ASyncConnectionSubFeedStatus_sample")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 4) {
			System.err.println("give SERVER PORT LOGIN PASSWORD");
			System.err.println("example: localhost 8000 toto titi");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];


		System.err.println("connecting...");
		
		/* override default socket settings */
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
	
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
					MySubscribeInstrumentsReceiverFeedStatus receiver = new MySubscribeInstrumentsReceiverFeedStatus();
		
		int subscription_num  = 0;
		// STORE the returned value: we'll need it to stop the subscription
		subscription_num = async_requester.asyncConnectiontSubscribeToFeedStatus_start
			(
					receiver,
					new String ("1")
			);
		 
		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping 60 seconds...");				
		System.err.flush();
		sleep (60*60);

		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();
	
		async_requester.asyncConnectionSubscribeToFeedStatus_stop (subscription_num);
		
		session.close();
		Session.shutdown_api();
	}
	
	
	
		
}