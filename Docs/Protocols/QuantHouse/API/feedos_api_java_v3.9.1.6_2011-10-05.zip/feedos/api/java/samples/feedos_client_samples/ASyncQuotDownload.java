package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2009 FeedOS
 * All Rights Reserved.
 * 
 * @author Dicharry
 */

class MyQuotationDownloadReceiver implements
Receiver_Quotation_DownloadInstruments
{
    
	public void quotDownloadInstrumentsResponse ( int subscription_num,
			Object user_context,
			long timestamp,
			int rc	)
	{
		System.out.println("...quotQuotationDownloadResponse "+PDU.date2ISOstring(timestamp));
	}

	public void quotDownloadInstrumentsFailed ( int subscription_num,
			Object user_context,
			int rc	)
	{
		System.out.println("...quotQuotationDownloadFailed");
	}
	
	public void quotDownloadInstrumentsUnsubNotif ( int subscription_num,
				Object user_context,
				int rc	)
	{
		System.out.println("...quotQuotationDownloadUnsubNotif");
	}
	
	public void quotDownloadInstrumentsBranchBegin ( MarketBranchId list_markets,
					int in_current_quantity, 
					int in_selected_quantity)
	{
		System.out.println("...quotQuotationDownloadBranchBegin");
		DumpFunctions.dump( list_markets );
		System.out.println(in_current_quantity+";"+in_selected_quantity);
	}
	
	public void quotDownloadInstruments ( InstrumentData[] instruments)
	{
		System.out.println("...quotQuotationDownloadInstruments: " + instruments.length);
		DumpFunctions.dump( instruments );
	}

		
}

public class ASyncQuotDownload {
	
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}

	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length < 4) {
			System.err.println("give SERVER PORT LOGIN PASSWORD MARKET_CODE  ");
			System.err.println("example: localhost 8000 toto titi XEUR ");
			return;
		}
		
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		int fos_market_id;
		if(args.length == 5)
		{
			String market_id_str = args[4];
			fos_market_id = Verbosity.getFOSMarketId (market_id_str);
			if (0==fos_market_id) {
				System.err.println("unknown MIC: "+market_id_str);
				return;
			}
		} else
		{
			// download referential for all markets
			fos_market_id = 0;
		}

		MarketBranchId[] list_markets = new MarketBranchId[1];
		list_markets[0] = new MarketBranchId(fos_market_id,"","");
		
		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
		
		MyQuotationDownloadReceiver receiver = new MyQuotationDownloadReceiver();
		
		// get the following referential tag values
		int[] ref_format = {
				Constants.TAG_FOSMarketId,
				Constants.TAG_LocalCodeStr,
				Constants.TAG_Symbol,
				Constants.TAG_CFICode,
				Constants.TAG_StrikePrice,
				Constants.TAG_ISIN,
		};		
		
		// get the following quotation tag values
		int[] quot_format = {
				Constants.TAG_DailyClosingPrice,
				Constants.TAG_PreviousDailyClosingPrice,
				Constants.TAG_InternalPriceActivityTimestamp
		};	
		
		/// try playing with the filter
		ListOfTagValue filter = new ListOfTagValue();
		//filter.enforceTagValue(Constants.TAG_SecurityType, Any.make_string("FUT"));
		filter.addTag(Constants.TAG_CFICode, Any.make_string("E"));

		async_requester.asyncQuotDownloadInstruments_start(
				receiver, 
				new String ("ASyncQuotQuotationDownload_sample"), 
				list_markets, 
				filter, 
				ref_format, 
				quot_format,
				0, 
				-1);
		
		sleep(60);
		
		//
		// stop the subscription
		//
		System.err.println("stopping subscription");	
		System.err.flush();
		
		session.close();
		Session.shutdown_api();
	}

	
}