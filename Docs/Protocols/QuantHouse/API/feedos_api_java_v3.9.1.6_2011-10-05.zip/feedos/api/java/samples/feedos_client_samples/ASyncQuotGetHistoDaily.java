package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2006 FeedOS
 * All Rights Reserved.
 * 
 * @author fenouil
 */
 


/** 
 * sample client that retrieves the Daily values (open/high/low/close/volume/asset) for an instrument
 */


class MyHistoDailyReceiver implements Receiver_Quotation_GetHistoryDaily
{
	
	public void quotGetHistoryDailyResponse (	Object user_context,		
			int rc,						
			int instrument_code,		
			int[] result_local_date,
			double[] result_open,
			double[] result_high,
			double[] result_low,
			double[] result_close,
			double[] result_daily_volume,
			double[] result_daily_asset
		)
	{
		DumpFunctions.DUMP ("==== async receive");
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("GetHistoryDaily failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.dump (instrument_code, result_local_date, result_open, result_high, result_low, result_close, result_daily_volume, result_daily_asset);
		}
	}
}



public class ASyncQuotGetHistoDaily {
			
	static Session session = new Session();		
	static MySessionObserver session_observer = new MySessionObserver();
	static RequestSender async_requester = new RequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");				
		System.err.println("sending (async) quot.getHistoDaily");
		System.err.flush();

		// begin date. All zeros would mean "beginning of time"
		int		begin_year	= 2005;
		int		begin_month	= 1;
		int		begin_day	= 1;
		
		// end date. All zero means "today"
		int		end_year	= 0;
		int		end_month	= 0;
		int		end_day		= 0;

		PolymorphicInstrumentCode instr = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		async_requester.asyncQuotGetHistoryDaily(new MyHistoDailyReceiver(),
												null,	// optional "user context"
												instr,	// target instrument
												begin_year, begin_month, begin_day,	// begin of range
												end_year, end_month, end_day		// end of range
											);

		// wait a bit to let the response arrive
		System.err.println("sleeping 10 seconds");				
		System.err.flush();
		sleep (10);

		session.close();
		Session.shutdown_api();
	}
	
	
	
		
}
















