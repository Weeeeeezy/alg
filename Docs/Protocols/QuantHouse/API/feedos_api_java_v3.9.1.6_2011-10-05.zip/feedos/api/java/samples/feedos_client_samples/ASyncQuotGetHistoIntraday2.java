package feedos_client_samples;

import java.util.Hashtable;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2003-2010 FeedOS
 * All Rights Reserved.
 */
 
/** 
 * sample client that retrieves the Intraday ticks (i.e. trades) for an instrument
 */

class MyHistoIntraday2Receiver implements Receiver_Quotation_GetHistoryIntraday2, Receiver_Referential_GetTradeConditionsDictionary
{
	
	public void refGetTradeConditionsDictionary (	Object user_context,
			int rc,				
			TradeConditionsDictionaryEntry[] result
			)
	{
		if ( Constants.RC_OK == rc )
		{
			DumpFunctions.DUMP ("==== GetTradeConditionsDictionary succeeded");	
			for (int i=0; i < result.length;i++)
			{
				tradeConditions.put(new Integer((int)(result[i].getIndex())), result[i].getValue());	
				System.out.println(result[i].printContent());
			}
		}
		else
		{
			DumpFunctions.DUMP ("GetTradeConditionsDictionary failed, rc="+PDU.getErrorCodeName(rc));		
		}
	}

	public ListOfTagValue getTradeConditions(int tradeConditionIndex)
	{
		return tradeConditions.get(new Integer(tradeConditionIndex));
	}
	
	public void quotGetHistoryIntraday2Response (		
			Object 		user_context,		
			int 		rc,						
			int 		r_instrument_code,		
			double[] 	r_Price,
			double[] 	r_LastTradeQty,
			long[]		r_MarketUTCTime,
			long[]		r_ServerUTCTime,
			QuotationContentMask[]	r_ContentMask,
			int[]		r_TradeConditionIndex		
		)
		{
		DumpFunctions.DUMP ("==== async receive");
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("GetHistoryIntraday2 failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			ListOfTagValue[] tradeConditions = null;
			if (r_TradeConditionIndex.length > 0)
			{
				tradeConditions = new ListOfTagValue[r_TradeConditionIndex.length];
				for (int i =0 ; i < r_TradeConditionIndex.length;i++)
				{
					tradeConditions[i] = getTradeConditions(r_TradeConditionIndex[i]);
				}
			}
			if (null != tradeConditions)
			{
				DumpFunctions.DUMP("server\tmarket\tprice\tqty\tcontent_mask\tTradeConditions");
				DumpFunctions.dump (r_instrument_code, r_Price, r_LastTradeQty, r_ServerUTCTime, r_MarketUTCTime, r_ContentMask, tradeConditions);
			}
			else
			{
				DumpFunctions.DUMP("server\tmarket\tprice\tqty\tcontent_mask\tTradeConditionIndex");
				DumpFunctions.dump (r_instrument_code, r_Price, r_LastTradeQty, r_ServerUTCTime, r_MarketUTCTime, r_ContentMask, r_TradeConditionIndex);
			}
		}
	}
	
	Hashtable<Integer, ListOfTagValue> tradeConditions = new Hashtable<Integer, ListOfTagValue>();
}

public class ASyncQuotGetHistoIntraday2 {
			
	static Session session = new Session();		
	static MySessionObserver session_observer = new MySessionObserver();
	static RequestSender async_requester = new RequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
		
		if (args.length != 5) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   INTERNAL_CODE");
			System.err.println("example: localhost 8000 toto titi 619409850");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		int internal_code =Integer.decode (args[4]).intValue();

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");				
		System.err.println("sending (async) quot.getTradeConditionsDictionary");
		System.err.flush();
		MyHistoIntraday2Receiver histo2Receiver = new MyHistoIntraday2Receiver();
		
		// perform a asynchronous request
		async_requester.asyncRefGetTradeConditionsDictionary(histo2Receiver,// receiver handling trade conditions dictionary download
															 null);			// optional "user context";

		// Let the request being processed
		sleep(30);
		
		System.err.println("sending (async) quot.getHistoIntraday2");
		System.err.flush();

		long end_utc_timestamp = System.currentTimeMillis();			// "now"
		long begin_utc_timestamp = (end_utc_timestamp -(86400*1000));	// "now -1 day"

		PolymorphicInstrumentCode instr = new PolymorphicInstrumentCode(internal_code);
		async_requester.asyncQuotGetHistoryIntraday2(histo2Receiver,
												null,					// optional "user context"
												instr,					// target instrument
												begin_utc_timestamp,	// begin of range
												end_utc_timestamp,		// end of range
												0						// retrieve all ticks
											);

		// wait a bit to let the response arrive
		System.err.println("sleeping 10 seconds");				
		System.err.flush();
		sleep (10);

		session.close();
		Session.shutdown_api();
	}
	
	
	
		
}
















