package feedos_client_samples;


import java.util.GregorianCalendar;
import java.util.TimeZone;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2004 FeedOS
 * All Rights Reserved.
 * 
 * @author Dicharry
 */
 

/** 
 *  
 */
class MyReplayInstrumentsReceiver implements Receiver_Quotation_MulticastDataReplayL1
{	
	MyReplayInstrumentsReceiver ()
	{
	}

	public void quotMulticastDataReplayL1Response (
			int subscription_num,
			Object user_context,
			int rc,						
			PolymorphicInstrumentCode[] result
		)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription started");
			DumpFunctions.dump (result);
		}
	}
	
	public void quotMulticastDataReplayL1UnsubNotif (
			int subscription_num,
			Object user_context,
			int rc)
	{
		DumpFunctions.DUMP ("==== Subscription aborted, rc="+PDU.getErrorCodeName(rc));			
	}
	
	public void quotNotifMulticastDataReplayHeader(
			int FrameSequenceNumber,
			int FrameServerDate_seconds,
			int FrameServerDate_millisec,
			int FrameServerDate_microsec,
			int FrameDuration_microsec,
			int NbMessagesInFrame		
			)
	{
		DumpFunctions.DUMP ("Data Replay Header " + FrameSequenceNumber + ";" + FrameServerDate_seconds + ";" + FrameServerDate_millisec + ";" + FrameServerDate_microsec + ";" +  FrameDuration_microsec + ";" + NbMessagesInFrame);
	}
	

	
	public void quotNotifTradeEventExt (
			int subscription_num,
			Object user_context,	
			int instrument_code, 
			long server_timestamp, 
			long market_timestamp, 
			QuotationTradeEventExt trade_event)
	{
		DumpFunctions.DUMP ("==== Trade Event EXT for instrument " + instrument_code + " on "+ PDU.date2ISOstring(market_timestamp));
		++DumpFunctions.indent_count;

		//
		// now parse the event and dump values
		//
		
		// check best limits
		if (trade_event.content_mask.isSetBidLimit()) {
			DumpFunctions.DUMP ("BEST BID: "+trade_event.best_bid_price+ " x "+ trade_event.best_bid_qty);			
		}
		if (trade_event.content_mask.isSetAskLimit()) {
			DumpFunctions.DUMP ("BEST ASK: "+trade_event.best_ask_price+ " x "+ trade_event.best_ask_qty);			
		}
		
		String flags = "";
		if (trade_event.content_mask.isSetOCHLdaily()) { flags += "<daily> "; }
		if (trade_event.content_mask.isSetOpen()) { flags += "OPEN "; }
		if (trade_event.content_mask.isSetClose()) { flags += "CLOSE "; }
		if (trade_event.content_mask.isSetHigh()) { flags += "HIGH "; }		
		if (trade_event.content_mask.isSetLow()) { flags += "LOW "; }

		if (flags.length() != 0) {
			DumpFunctions.DUMP ("flags: "+flags);	
		}
		
		// check price/trade update
		if (trade_event.content_mask.isSetLastPrice()) {
			if (trade_event.content_mask.isSetLastTradeQty()) {
				DumpFunctions.DUMP ("TRADE: "+trade_event.price + " x "+ trade_event.last_trade_qty);
			} else {
				DumpFunctions.DUMP ("PRICE: "+trade_event.price);				
			}			
		} else {
			if (flags.length() != 0) {
				DumpFunctions.DUMP ("OCHL value: "+trade_event.price);								
			}
		}
		
		--DumpFunctions.indent_count;	
	}
	
	public void quotNotifMarketNewsEvent (	int subscription_num,
			Object user_context,	
			int FOSMarketId,
			long Timestamp, 
			int FIXMarketNewsUrgency,
			String Headline,
			String URLLink,
			String Content,
			PolymorphicInstrumentCode[]  RelatedInstruments)
	{
		DumpFunctions.DUMP("quotNotifMarketNewsEvent received");
		++DumpFunctions.indent_count;
		
		DumpFunctions.DUMP("FOSMarketId: " + Verbosity.getISOMarketName(FOSMarketId));
		DumpFunctions.DUMP("Timestamp: " +PDU.date2ISOstring(Timestamp));
		DumpFunctions.DUMP("FIXMarketNewsUrgency: " +FIXMarketNewsUrgency);
		DumpFunctions.DUMP("Headline: " +Headline);
		DumpFunctions.DUMP("URLLink: " +URLLink);
		DumpFunctions.DUMP("Content: " +Content);
		DumpFunctions.DUMP("RelatedInstruments: "); DumpFunctions.dump (RelatedInstruments);
		
		--DumpFunctions.indent_count;	
	}
}



public class ASyncQuotMulticastDataReplayL1 {
			
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD MARKET_CODE LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 joe secret XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
			
		PolymorphicInstrumentCode[] instr_list = new PolymorphicInstrumentCode[1];
		instr_list[0] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
	
		System.err.println("starting subscription, content_mask=EVERYTHING");
		System.err.flush();

		// build the receiver
		MyReplayInstrumentsReceiver receiver = new MyReplayInstrumentsReceiver();
		
		GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
		calendar.set(2011,GregorianCalendar.MAY,16,8,0,0);
		long start_time = calendar.getTime().getTime();
		calendar.set(2011,GregorianCalendar.MAY,16,18,0,0);
		long stop_time = calendar.getTime().getTime();
		
		// Specify replay ranges 
		int internalSourceId = 20002;
		int[] filterMICs = null;
		// Here, a request to replay L1 events for source internalSourceId filtered on instrument list instr_list is built
		// To built a request to replay the whole internal source, instr_list and filterMICs have to be null.
		QuotationReplaySubject replay_subject = new QuotationReplaySubject(
													internalSourceId,
													start_time,
													stop_time,
													true,		// ask to receive MulticastDataReplayHeader events
													instr_list, // filter replay on input instr_list, if null , the whole source will be replayed
													filterMICs,	// no filtering on MIC specified
													false,		// don't ignore invalid codes, if any request will abort
													0			// replay factor set to default
											);
		
		// Specify content filtering if any
		QuotationContentMask requested_content = new QuotationContentMask (true);	// all L1 events is specified, no filtering on content mask is done
		QuotationReplayL1Filter replay_filter = new QuotationReplayL1Filter(null, requested_content); // no other values filter
		
		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotMulticastDataReplayL1_start
			(
					receiver,
					new String ("user context to distinguish requests"),
					replay_subject,
					replay_filter
			);

		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping 60 seconds ... Trades/Limits events may occur");				
		System.err.flush();
		sleep (60);


		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();
	
		async_requester.asyncQuotMulticastDataReplayL1_stop (subscription_num);
		
		session.close();
		Session.shutdown_api();
	}	
		
}
