package feedos_client_samples;

import java.util.GregorianCalendar;
import java.util.TimeZone;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;

/*
 * (c) Copyright 2004 FeedOS
 * All Rights Reserved.
 * 
 * @author fenouil
 */
 


/** 
 * sample client that subscribes to an instrument's order book (full depth)
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */


class MyReplayBookReceiver implements Receiver_Quotation_MulticastDataReplayL2
{
	
	InstrumentQuotationData	instr_status;
	MBLSnapshot			m_Snapshot;
	
	MBLSnapshot getOrCreateSnapshot(int instrumentCode)
	{
		if (null == m_Snapshot && 0 != instrumentCode)
		{
			m_Snapshot = new MBLSnapshot(instrumentCode, null);
		}
		return m_Snapshot;
	}
	
	public void quotMulticastDataReplayL2Response 
	(	int subscription_num,
			Object user_context,
			int rc,		
			PolymorphicInstrumentCode[] instrument_code
		)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription to Book failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription to Book started");
		}
	}

	public void quotMulticastDataReplayL2UnsubNotif (
			int subscription_num,
			Object user_context,
			int rc)
	{
		DumpFunctions.DUMP ("==== Subscription to Book aborted, rc="+PDU.getErrorCodeName(rc));			
	}

	public void quotNotifMulticastDataReplayHeader(
			int FrameSequenceNumber,
			int FrameServerDate_seconds,
			int FrameServerDate_millisec,
			int FrameServerDate_microsec,
			int FrameDuration_microsec,
			int NbMessagesInFrame		
			)
	{
		DumpFunctions.DUMP ("Data Replay Header " + FrameSequenceNumber + ";" + FrameServerDate_seconds + ";" + FrameServerDate_millisec + ";" + FrameServerDate_microsec + ";" +  FrameDuration_microsec + ";" + NbMessagesInFrame);
	}
	
	public void quotNotifOrderBookRefresh
			(	int subscription_num,
				Object user_context,	
				int instrument_code, 
				long timestamp,
				int bid_change_indicator,
				int ask_change_indicator,
				double[] bid_prices, 
				double[] bid_quantities,
				double[] ask_prices, 
				double[] ask_quantities
			)
	{
		DumpFunctions.DUMP ("==== Book Refresh");
		DumpFunctions.DUMP ("  bid_indic="+bid_change_indicator);
		DumpFunctions.DUMP ("  ask_indic="+ask_change_indicator);
		OrderBookSide bid_side = new OrderBookSide (bid_prices, bid_quantities);
		OrderBookSide ask_side = new OrderBookSide (ask_prices, ask_quantities);
		DumpFunctions.dump (new OrderBook (timestamp, bid_side, ask_side));	
		
		// update "cached" data
		instr_status.update_with_OrderBookRefresh
				(	timestamp,
					bid_change_indicator,
					ask_change_indicator,
					bid_prices, 
					bid_quantities,
					ask_prices, 
					ask_quantities
				);
		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (instr_status.getOrderBook());
	}


	public void quotNotifOrderBookDeltaRefresh
			(	int subscription_num,
				Object user_context,	
				int instrument_code, 
				long timestamp,
				int ob_delta_action,
				int level,
				double price,
				double qty
			)
	{
		String date_str = PDU.date2ISOstring(timestamp);	// returns "null" if timestamp==0
		
		// dump "raw" data
		DumpFunctions.DUMP ("==== Book Delta Refresh, timestamp="+ date_str);
		DumpFunctions.DUMP ("  ob_delta_action="+ob_delta_action);
		DumpFunctions.DUMP ("  level="+level);
		DumpFunctions.DUMP ("  price="+price);
		DumpFunctions.DUMP ("  qty="+qty);
		
		// update "cached" data
		instr_status.update_with_OrderBookDeltaRefresh(timestamp, ob_delta_action, level, price, qty);
		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (instr_status.getOrderBook());
	}
	
	public void quotNotifMBLFullRefresh	(	
			int subscription_num,
			Object user_context,	
			MBLSnapshot[] snapshots)
	{
		if (null != snapshots && snapshots.length > 0)
		{	
			m_Snapshot = snapshots[0];
			
			DumpFunctions.DUMP ("  instrument="+m_Snapshot.getCode());	
			int sizeLayers = (null != m_Snapshot.getLayers()) ? m_Snapshot.getLayers().size() : 0;
			for ( int j = 0; j < sizeLayers; j++)
			{
				DumpFunctions.dump(m_Snapshot.getLayers().elementAt(j));
			}			
		}
	}
	
	public void quotNotifMBLOverlapRefresh(	
			int subscription_num,
			Object user_context,	
			MBLOverlapRefresh overlap)
	{
		System.out.print("OR ");
		DumpFunctions.dumpMblHeader(overlap.getCode(),overlap.getLayerId(),overlap.getTimestamps());
		
		DumpFunctions.DUMP ("  bid_indic="+overlap.getBidChangeIndicator()+"  ask_indic="+overlap.getAskChangeIndicator());
		DumpFunctions.DUMP("bid side");
		++DumpFunctions.indent_count;
		DumpFunctions.dumpMbl (overlap.getBidLimits());
		--DumpFunctions.indent_count;
		DumpFunctions.DUMP("ask side");
		++DumpFunctions.indent_count;
		DumpFunctions.dumpMbl (overlap.getAskLimits());
		--DumpFunctions.indent_count;
		if (null != overlap.getOtherValues())
		{
			DumpFunctions.DUMP("OtherValues: "); DumpFunctions.dump(overlap.getOtherValues());	
		}

		
		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (getOrCreateSnapshot(overlap.getCode()).update_with_MBLOverlapRefresh(overlap));
	}
	
	public void quotNotifMBLDeltaRefresh(
			int subscription_num,
			Object user_context,	
			MBLDeltaRefresh delta)
	{
		System.out.print("OD ");

		DumpFunctions.dumpMblHeader(delta.getCode(),delta.getLayerId(),delta.getTimestamps());
		
		DumpFunctions.dumpAction(delta.getAction());
		DumpFunctions.DUMP ( " level="+delta.getLevel()+ " price="+Constants.print_price(delta.getPrice()) + "  cumulated_qty="+delta.getCumulatedUnits()
							+ " nb_orders="+Constants.print_nbOrders(delta.getNbOrders()));	

		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (getOrCreateSnapshot(delta.getCode()).update_with_MBLDeltaRefresh(delta));
	}
	
	public void quotNotifMBLMaxVisibleDepth	(	
			int subscription_num,
			Object user_context,
			MBLMaxVisibleDepth depth)
	{
		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (getOrCreateSnapshot(depth.getCode()).update_with_MBLMaxVisibleDepth(depth));
	}
}

public class ASyncQuotMulticastDataReplayL2 {
			
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD");
			System.err.println("example: localhost 8000 joe secret");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
		
		
		PolymorphicInstrumentCode[] instr_list = new PolymorphicInstrumentCode[1];
		instr_list[0] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		System.err.println("starting subscription to book");
		System.err.flush();
	
		GregorianCalendar calendar = new GregorianCalendar(TimeZone.getTimeZone("UTC"));
		calendar.set(2010,GregorianCalendar.JANUARY,1,8,0,0);
		long start_time = calendar.getTime().getTime();
		calendar.set(2010,GregorianCalendar.JANUARY,28,17,0,0);
		long stop_time = calendar.getTime().getTime();
		
		int internalSourceId = 0;
		QuotationReplaySubject replay_subject = new QuotationReplaySubject(
													internalSourceId,
													start_time,
													stop_time,
													true,
													instr_list,
													null,
													true,
													0
											);
		
		QuotationReplayL2Filter replay_filter = new QuotationReplayL2Filter(-1);
		
		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotMulticastDataReplayL2_start
			(
					new MyReplayBookReceiver(),
					new String ("user context to distinguish requests"),
					replay_subject,
					replay_filter
			);

		System.err.println("strike a key to stop L2 replay");
		try 
		{
			System.in.read();
		} 
		catch(java.io.IOException IoExc)
		{	
		}
		
		//
		// stop the subscription
		//
		async_requester.asyncQuotMulticastDataReplayL2_stop (subscription_num);
		
		session.close();
		Session.shutdown_api();
	}
	
	
	
		
}
















