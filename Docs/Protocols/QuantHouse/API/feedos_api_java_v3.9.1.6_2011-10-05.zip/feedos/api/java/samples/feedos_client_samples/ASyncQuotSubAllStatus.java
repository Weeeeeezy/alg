package feedos_client_samples;


import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */
 

class MySubscribeAllStatus implements 
				Receiver_Quotation_SubscribeAllStatus
{
	public void quotSubscribeAllStatusResponse(
			int subscription_num,
			Object user_context,
			int rc	
	)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription started");
		}
	}
	
	public void quotSubscribeAllStatusUnsubNotif (
			int subscription_num,
			Object user_context,
			int rc
	)
	{
		DumpFunctions.DUMP ("==== Subscription aborted, rc="+PDU.getErrorCodeName(rc));	
	}
	
	public void quotNotifMarketNewsEvent (	int subscription_num,
			Object user_context,	
			int FOSMarketId,
			long Timestamp, 
			int FIXMarketNewsUrgency,
			String Headline,
			String URLLink,
			String Content,
			PolymorphicInstrumentCode[]  RelatedInstruments
	)
	{
		DumpFunctions.DUMP(" quotNotifMarketNewsEvent received !");
		++DumpFunctions.indent_count;
		
		DumpFunctions.DUMP("FOSMarketId: "+FOSMarketId);
		DumpFunctions.DUMP("Timestamp: " +Timestamp);
		DumpFunctions.DUMP("FIXMarketNewsUrgency: " +FIXMarketNewsUrgency);
		DumpFunctions.DUMP("Headline: " +Headline);
		DumpFunctions.DUMP("URLLink: " +URLLink);
		DumpFunctions.DUMP("Content: " +Content);
		DumpFunctions.DUMP("RelatedInstruments: "); DumpFunctions.dump (RelatedInstruments);
		
		--DumpFunctions.indent_count;	

	}
	
}



public class ASyncQuotSubAllStatus {
			
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0, 1000);
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_marketstatus_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 4) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   ");
			System.err.println("example: localhost 8000 toto titi");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
			
		// build the receiver
		MySubscribeAllStatus receiver = new MySubscribeAllStatus();
		
		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotSubscribeAllStatus_start
			(
					receiver,
					new String ("user context to distinguish requests")
			);

		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping 60 seconds");				
		System.err.flush();
		sleep (5);


		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();
	
		async_requester.asyncQuotSubscribeAllStatus_stop (subscription_num);
		
		session.close();
		async_requester.terminate();
		Session.shutdown_api();
	}
	
	
	
		
}