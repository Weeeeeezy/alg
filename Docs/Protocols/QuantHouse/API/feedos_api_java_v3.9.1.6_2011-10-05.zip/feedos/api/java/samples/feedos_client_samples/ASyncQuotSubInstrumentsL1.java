package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */
 


/** 
 * sample client that subscribe to an instrument to get trades/best limits/trading status
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */

public class ASyncQuotSubInstrumentsL1 {
			
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();	
	static RequestSender async_requester = new RequestSender (session, 0);

	
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	
	
	public static void main(String args[]) {
		
		if (0 != Session.init_api("ASyncQuotSubInstrumentsL1_sample")) {
			System.err.println("cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
		
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
				
		ProxyFeedosTCP my_socket_proxy = new ProxyFeedosTCP(server, port, new Credentials(login, password));
		int rc=session.open	(session_observer, my_socket_proxy, 0);
	
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
			
		int nb_instr = 1;
		
		QuotationContentMask requested_content = new QuotationContentMask (true);	// request all events
		PolymorphicInstrumentCode[] instr_list = new PolymorphicInstrumentCode[nb_instr];
		
		for(int i = 0; i < nb_instr; i++)
		{
			instr_list[i] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		}
		
		System.err.println("starting subscription, content_mask=EVERYTHING");
		System.err.flush();

		// build the receiver
		MySubscribeInstrumentsReceiverL1 receiver = new MySubscribeInstrumentsReceiverL1(instr_list);
		
		int subscription_num  = 0;
		String user_context = "1";
		int waiting_time = 5;
		
		// STORE the returned value: we'll need it to stop the subscription
		subscription_num = async_requester.asyncQuotSubscribeInstrumentsL1_start
			(
					receiver,
					user_context,
					instr_list,		// list of instr code
					null,			// other variables to look for (none)
					requested_content
			);
		 
		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping "+waiting_time+" seconds ... Trades/Limits events may occur");				
		System.err.flush();
		sleep (waiting_time);

		//
		// remove the instrument
		//
		try {
			async_requester.asyncQuotChgSubscribeInstrumentsL1_removeInstruments(subscription_num, receiver, user_context, instr_list);
		} catch (FeedOSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.err.println("sleeping "+waiting_time+" seconds ... No Trades/Limits events should occur");				
		System.err.flush();
		sleep (waiting_time);
		
		//
		// re add the instrument
		//
		try {
			async_requester.asyncQuotChgSubscribeInstrumentsL1_addInstruments(subscription_num, receiver, user_context, instr_list);
		} catch (FeedOSException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.err.println("sleeping "+waiting_time+" seconds ... Trades/Limits events may occur");				
		System.err.flush();
		sleep (waiting_time);
		
		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();
	
		async_requester.asyncQuotSubscribeInstrumentsL1_stop (subscription_num);
		
		receiver.declareEndOfSubscription(subscription_num, user_context, Constants.RC_OK);
		
		//receiver.quotSubscribeInstrumentsL1UnsubNotif(0,0,0);
		
		session.close();
		Session.shutdown_api();
	}
	
	
	
		
}