package feedos_client_samples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.*;

/*
 * (c) Copyright 2009 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

public class ASyncQuotSubInstrumentsL1_with_factory {

	static RequestSender async_requester;// = new RequestSender(session, 0);
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();	
	
	public static void main(String args[]) {

		if (0 != Session.init_api("ASyncQuotSubInstrumentsL1_sample")) {
			System.err.println("cannot initialise FeedOS API ");
			return;
		}

		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers,
		// etc.
		Verbosity.enableVerbosity();

		if (args.length != 2) {
			System.err.println("give conf_file instr_file");
			System.err.println("example: conf.xml instr.xml");
			return;
		}

		// filled from arguments
		String xml_file = args[0];
		String instr_file = args[1];
		
		System.err.println("connecting...");
				
		HashMap<String,ProxyFeedos> proxies = ProxyFactory.buildProxies(xml_file);
		
		HashMap<String,PolymorphicInstrumentCode[]> codes = ProxyFactory.buildInstrumentLists(instr_file);
		
		/*
		 * take the first configuration and the first instrument list
		 */
		ProxyFeedos proxy = proxies.values().iterator().next();
		PolymorphicInstrumentCode[] instr_list= codes.values().iterator().next();
		
		int rc=session.open	(session_observer, proxy, 0);
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		
		async_requester = new RequestSender(session, 0);
		
		System.err.println("connection OK");
		System.err.flush();

		QuotationContentMask requested_content = new QuotationContentMask(true); // request
		
		MySubscribeInstrumentsReceiverL1 receiver = new MySubscribeInstrumentsReceiverL1(instr_list);
		
		int subscription_num = 0;
		// STORE the returned value: we'll need it to stop the subscription
		subscription_num = async_requester
				.asyncQuotSubscribeInstrumentsL1_start(receiver, new String(
						"pipe"), instr_list, // list of instr code
						null, // other variables to look for (none)
						requested_content);

		// wait a bit to let the response/notifications arrive
		System.err.println("Trades/Limits events may occur");
		System.err.flush();

		try {
			new BufferedReader(new InputStreamReader(System.in)).readLine();
		} catch (IOException e1) {
		}

		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();

		async_requester.asyncQuotSubscribeInstrumentsL1_stop(subscription_num);

		session.close();
	}

}