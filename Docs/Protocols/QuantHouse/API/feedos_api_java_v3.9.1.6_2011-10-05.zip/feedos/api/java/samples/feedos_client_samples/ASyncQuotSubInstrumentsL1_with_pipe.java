package feedos_client_samples;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;

/*
 * (c) Copyright 2009 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

public class ASyncQuotSubInstrumentsL1_with_pipe {

	private static Session session = new Session();
	static RequestSender async_requester = new RequestSender(session, 0);
	static MySessionObserver session_observer = new MySessionObserver();
	
	public static void main(String args[]) {

		if (0 != Session.init_api("ASyncQuotSubInstrumentsL1_sample")) {
			System.err.println("cannot initialise FeedOS API ");
			return;
		}

		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers,
		// etc.
		Verbosity.enableVerbosity();

		if (args.length != 5) {
			System.err.println("give SERVER_URL LOGIN PASSWORD  MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: /home/feedos/cme_stream_server/ toto titi XEUR FDAX1205");
			return;
		}

		// filled from arguments
		String server_directory = args[0];
		String login = args[1];
		String password = args[2];

		String market_id_str = args[3];
		int fos_market_id = Verbosity.getFOSMarketId(market_id_str);
		if (0 == fos_market_id) {
			System.err.println("unknown MIC: " + market_id_str);
			return;
		}
		String localcode_str = args[4];

		System.err.println("connecting...");

		ProxyFeedos my_piped_proxy = new ProxyFeedosIPC(server_directory, new Credentials(login, password));
		int rc=session.open	(session_observer, my_piped_proxy, 0);

		if (rc != Constants.RC_OK) {
			System.err.println("Cannot connect: rc=" + PDU.getErrorCodeName(rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();

		QuotationContentMask requested_content = new QuotationContentMask(true); // request

		PolymorphicInstrumentCode[] instr_list = new PolymorphicInstrumentCode[1];
		instr_list[0] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		MySubscribeInstrumentsReceiverL1 receiver = new MySubscribeInstrumentsReceiverL1(instr_list);
		
		int subscription_num = 0;
		// STORE the returned value: we'll need it to stop the subscription
		subscription_num = async_requester.asyncQuotSubscribeInstrumentsL1_start(receiver, new String(
						"pipe"), instr_list, // list of instr code
						null, // other variables to look for (none)
						requested_content);

		// wait a bit to let the response/notifications arrive
		System.err.println("Trades/Limits events may occur");
		System.err.flush();

		try {
			new BufferedReader(new InputStreamReader(System.in)).readLine();
		} catch (IOException e1) {
		}

		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();

		async_requester.asyncQuotSubscribeInstrumentsL1_stop(subscription_num);

		session.close();
		Session.shutdown_api();

	}

}