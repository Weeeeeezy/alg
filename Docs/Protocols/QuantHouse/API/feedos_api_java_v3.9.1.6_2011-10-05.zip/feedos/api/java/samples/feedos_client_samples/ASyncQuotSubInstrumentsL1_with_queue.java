package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */
 


/** 
 * sample client that subscribe to an instrument to get trades/best limits/trading status
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */

public class ASyncQuotSubInstrumentsL1_with_queue {
			
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();	
	
	/*
	 * Create a request sender with a message queue. The size will be of 1000 updates.
	 */
	static RequestSender async_requester = new RequestSender (session, 0, 1000);

	
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	
	public static void main(String args[]) {
		
		if (0 != Session.init_api("ASyncQuotSubInstrumentsL1_sample")) {
			System.err.println("cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);
		
		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
			
		
		QuotationContentMask requested_content = new QuotationContentMask (true);	// request all events
		PolymorphicInstrumentCode[] instr_list = new PolymorphicInstrumentCode[1];
		instr_list[0] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		System.err.println("starting subscription, content_mask=EVERYTHING");
		System.err.flush();

		// build the receiver
		MySubscribeInstrumentsReceiverL1 receiver = new MySubscribeInstrumentsReceiverL1(instr_list);
		
		int subscription_num  = 0;
		// STORE the returned value: we'll need it to stop the subscription
		subscription_num = async_requester.asyncQuotSubscribeInstrumentsL1_start
			(
					receiver,
					new String ("1"),
					instr_list,		// list of instr code
					null,			// other variables to look for (none)
					requested_content
			);
		 
		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping 60 seconds ... Trades/Limits events may occur");				
		System.err.flush();
		sleep (60);

		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();
	
		async_requester.asyncQuotSubscribeInstrumentsL1_stop (subscription_num);
		
		session.close();
		
		/*
		 * When the request sender is not used anymore, the terminate() will shutdown the message queue and the associated thread.
		 */
		async_requester.terminate();
		
		Session.shutdown_api();
	}
	
	
	
		
}