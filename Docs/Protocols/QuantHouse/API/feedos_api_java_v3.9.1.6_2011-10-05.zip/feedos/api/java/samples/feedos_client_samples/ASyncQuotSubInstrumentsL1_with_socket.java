package feedos_client_samples;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2009 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

public class ASyncQuotSubInstrumentsL1_with_socket {

	static Session session = new Session();	
	static RequestSender async_requester = new RequestSender (session, 0);
	static MySessionObserver session_observer = new MySessionObserver();
	
	public static void main(String args[]) {

		if (0 != Session.init_api("ASyncQuotSubInstrumentsL1_sample")) {
			System.err.println("cannot initialise FeedOS API ");
			return;
		}

		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
				
		if (args.length != 6) {
			System.err.println("give server port LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR ");
			System.err.println("example: localhost 6020 toto titi XEUR FDAX1205");
			return;
		}

		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		
		System.err.println("starting subscription, content_mask=EVERYTHING");
		System.err.flush();
		
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		
		System.err.println("connection OK");
		System.err.flush();

		QuotationContentMask requested_content = new QuotationContentMask (true);	// request all events
		PolymorphicInstrumentCode[] instr_list = new PolymorphicInstrumentCode[1];
		instr_list[0] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		// build the receiver
		MySubscribeInstrumentsReceiverL1 receiver = new MySubscribeInstrumentsReceiverL1(instr_list);
		
		int subscription_num  = 0;
		// STORE the returned value: we'll need it to stop the subscription
		subscription_num = async_requester.asyncQuotSubscribeInstrumentsL1_start
			(
					receiver,
					new String ("socket"),
					instr_list,		// list of instr code
					null,			// other variables to look for (none)
					requested_content
			);
		 
		// wait a bit to let the response/notifications arrive
		System.err.println("Trades/Limits events may occur");				
		System.err.flush();


		try {
			new BufferedReader(new InputStreamReader(System.in)).readLine();
		} catch (IOException e1) {
		}

		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();

		async_requester.asyncQuotSubscribeInstrumentsL1_stop (subscription_num);
		
		session.close();
		Session.shutdown_api();
	}

}