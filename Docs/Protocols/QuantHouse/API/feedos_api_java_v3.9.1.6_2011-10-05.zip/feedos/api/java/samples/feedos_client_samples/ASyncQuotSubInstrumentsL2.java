package feedos_client_samples;

import java.util.Hashtable;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;

/*
 * (c) Copyright 2009 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

/** 
 * sample client that subscribes to an instrument's order book (full depth)
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */
@Deprecated
class MySubscribeL2Receiver implements 
Receiver_Quotation_SubscribeInstrumentsL2,
Receiver_Quotation_ChgSubscribeInstrumentsL2
{
	Hashtable<Integer, InstrumentQuotationData> instrMap = new Hashtable<Integer, InstrumentQuotationData>();

	//InstrumentQuotationData	instr_status;

	public void quotSubscribeInstrumentsL2Response (	int subscription_num,
			Object user_context,
			int rc,						
			PolymorphicInstrumentCode[] instrument_codes,
			OrderBook[] instrument_orderbook
	)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription to Book failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription to Book started");
			// create new entries in the map, one per instrument received
			for (int i=0; i<instrument_codes.length; ++i) {

				InstrumentQuotationData instr_status = new InstrumentQuotationData(instrument_codes[i], instrument_orderbook[i]);
				DumpFunctions.dump(instr_status);

				int internal_instr_code = instr_status.getInstrumentCode().get_internal_code();

				if (0 == internal_instr_code) {
					// this may happen: 
					// 1) an invalid instr code was provided in request 
					// 2) IgnoreInvalidCodes was set to true (hence the request succeded despite the invalid input)
				} else {		
					// create the entry
					instrMap.put (new Integer (internal_instr_code), instr_status);
				}
			}
		}
	}

	public void quotSubscribeInstrumentsL2UnsubNotif (
			int subscription_num,
			Object user_context,
			int rc)
	{
		DumpFunctions.DUMP ("==== Subscription to Book aborted, rc="+PDU.getErrorCodeName(rc));			
	}


	public void quotNotifOrderBookMaxVisibleDepth	(	
			int subscription_num,
			Object user_context,	
			int instrument_code, 
			int cur_max_depth
	)
	{
		DumpFunctions.DUMP ("==== MaxVisibleDepth="+cur_max_depth);	

		InstrumentQuotationData instr_status = (InstrumentQuotationData) instrMap.get(new Integer (instrument_code));
		instr_status.update_with_MaxVisibleDepth (cur_max_depth);
	}


	public void quotNotifOrderBookRefresh
	(	int subscription_num,
			Object user_context,	
			int instrument_code, 
			long timestamp,
			int bid_change_indicator,
			int ask_change_indicator,
			double[] bid_prices, 
			double[] bid_quantities,
			double[] ask_prices, 
			double[] ask_quantities
	)
	{
		DumpFunctions.DUMP ("==== Book Refresh");
		DumpFunctions.DUMP ("  bid_indic="+bid_change_indicator);
		DumpFunctions.DUMP ("  ask_indic="+ask_change_indicator);
		OrderBookSide bid_side = new OrderBookSide (bid_prices, bid_quantities);
		OrderBookSide ask_side = new OrderBookSide (ask_prices, ask_quantities);
		DumpFunctions.dump (new OrderBook (timestamp, bid_side, ask_side));	

		// update "cached" data
		InstrumentQuotationData instr_status = (InstrumentQuotationData) instrMap.get(new Integer (instrument_code));
		instr_status.update_with_OrderBookRefresh
		(	timestamp,
				bid_change_indicator,
				ask_change_indicator,
				bid_prices, 
				bid_quantities,
				ask_prices, 
				ask_quantities
		);
		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (instr_status.getOrderBook());
	}


	public void quotNotifOrderBookDeltaRefresh
	(	int subscription_num,
			Object user_context,	
			int instrument_code, 
			long timestamp,
			int ob_delta_action,
			int level,
			double price,
			double qty
	)
	{
		String date_str = PDU.date2ISOstring(timestamp);	// returns "null" if timestamp==0

		// dump "raw" data
		DumpFunctions.DUMP ("==== Book Delta Refresh, timestamp="+ date_str);
		DumpFunctions.DUMP ("  ob_delta_action="+ob_delta_action);
		DumpFunctions.DUMP ("  level="+level);
		DumpFunctions.DUMP ("  price="+price);
		DumpFunctions.DUMP ("  qty="+qty);

		// update "cached" data
		InstrumentQuotationData instr_status = (InstrumentQuotationData) instrMap.get(new Integer (instrument_code));
		instr_status.update_with_OrderBookDeltaRefresh(timestamp, ob_delta_action, level, price, qty);
		DumpFunctions.DUMP ("== updated book");
		DumpFunctions.dump (instr_status.getOrderBook());
	}


	public void quotChgSubscribeInstrumentsAddInstrumentsL2Response (	
			Object user_context,		
			int rc,						
			PolymorphicInstrumentCode[] instrument_codes,
			OrderBook[] instrument_orderbook
	)
	{

	}

	public void quotChgSubscribeInstrumentsRemoveInstrumentsL2Response (	
			Object user_context,		
			int rc				
	)
	{

	}
}


@Deprecated
public class ASyncQuotSubInstrumentsL2 {

	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);

	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}


	public static void main(String[] args) {

		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}

		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();

		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi XEUR FDAX1205");
			return;
		}

		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();

		PolymorphicInstrumentCode instr_codes[] = new PolymorphicInstrumentCode[1];
		instr_codes[0] = new PolymorphicInstrumentCode(fos_market_id, localcode_str);

		System.err.println("starting subscription to book");
		System.err.flush();

		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotSubscribeInstrumentsL2_start
		(
				new MySubscribeL2Receiver(),
				new String ("user context to distinguish requests"),
				instr_codes
		);

		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping 10 seconds");				
		System.err.flush();
		sleep (10);

		// now remove the (unique) instrument and wait a bit
		System.err.println("changing subscription, removing the instrument");
		System.err.flush();

		try {
			sync_requester.syncQuotChgSubscribeInstrumentsL2_removeInstruments (subscription_num, instr_codes);

			// wait a bit to let the response/notifications arrive (none should arrive at this time)
			System.err.println("sleeping 10 seconds ... no event should occur");				
			System.err.flush();
			sleep (10);

		} catch (FeedOSException tfEx) {
			System.err.println("error in syncQuotChgSubscribeInstrumentsL2_removeInstruments: " + tfEx);
		}


		// now re-add the instrument and wait a bit

		System.err.println("changing subscription, re-adding the instrument");
		System.err.flush();

		try {
			sync_requester.syncQuotChgSubscribeInstrumentsL2_addInstruments (subscription_num, instr_codes);

			// wait a bit to let the response/notifications arrive (none should arrive at this time)
			System.err.println("sleeping 30 seconds ... Trade events may occur again");				
			System.err.flush();
			sleep (30);

		} catch (FeedOSException tfEx) {
			System.err.println("error in syncQuotChgSubscribeInstrumentsL2_addInstruments: " + tfEx);
		}

		//
		// stop the subscription
		//
		async_requester.asyncQuotSubscribeInstrumentsL2_stop (subscription_num);


		session.close();
		Session.shutdown_api();
	}




}
















