package feedos_client_samples;

import java.util.Hashtable;
import java.util.Vector;

import java.io.FileReader;
import java.io.FileNotFoundException;
import java.io.BufferedReader;
import java.io.IOException;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;

/*
 * (c) Copyright 2010 FeedOS
 * All Rights Reserved.
 * 
 * @author prodhomme
 */

/** 
 * sample client that subscribes to an instrument's mbl (full depth)
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */

class MySubscribeMBLReceiver implements 
Receiver_Quotation_SubscribeInstrumentsMBL
{
	Hashtable<Integer, MBLSnapshot> snapshotsMap = new Hashtable<Integer, MBLSnapshot>();

	private MBLSnapshot getOrCreateSnapshot(int internal_code)
	{
		if (0 != internal_code)
		{
			Integer snapshotKey = new Integer(internal_code);
			if (snapshotsMap.containsKey(snapshotKey))
			{
				return (MBLSnapshot) snapshotsMap.get(snapshotKey);
			}
			else 
			{
				MBLSnapshot blankSnapshot = new MBLSnapshot(internal_code,null);
				snapshotsMap.put (snapshotKey, blankSnapshot);
				return blankSnapshot;
			}
		}
		return null;
	}
	public void quotSubscribeInstrumentsMBLResponse (	int subscription_num,
			Object user_context,
			int rc,
			PolymorphicInstrumentCode[] InternalCodes
	)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription to MBL failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription to MBL started");
		}
	}

	public void quotSubscribeInstrumentsMBLUnsubNotif (
			int subscription_num,
			Object user_context,
			int rc)
	{
		DumpFunctions.DUMP ("==== Subscription to MBL aborted, rc="+PDU.getErrorCodeName(rc));			
	}
	
	public void quotNotifMBLFullRefresh	(	
			int subscription_num,
			Object user_context,	
			MBLSnapshot[] snapshots)
	{
		System.out.print("OF ");
		for (int i=0; i<snapshots.length;i++)
		{
			MBLSnapshot snapshot = snapshots[i];
			if (null != snapshot)
			{
				// first clean existing snapshots in map
				Integer codeKey = new Integer (snapshot.getCode());
				snapshotsMap.remove(codeKey);
				// set new snapshots in snapshotsMap
				DumpFunctions.DUMP ("  instrument="+snapshots[i].getCode());
				int sizeLayers = (null != snapshot.getLayers()) ? snapshot.getLayers().size() : 0;
				for ( int j = 0; j < sizeLayers; j++)
				{
					DumpFunctions.dump(snapshot.getLayers().elementAt(j));
					if (0 == snapshot.getCode()) {
						// this may happen: 
						// 1) an invalid instr code was provided in request 
						// 2) IgnoreInvalidCodes was set to true (hence the request succeded despite the invalid input)
					} else {		
						// store the snapshot
						snapshotsMap.put (codeKey, snapshot);
					}
				}
			}
		}
	}

	public void quotNotifMBLOverlapRefresh(	
			int subscription_num,
			Object user_context,	
			MBLOverlapRefresh overlap)
	{
		System.out.print("OR ");
		DumpFunctions.dumpMblHeader(overlap.getCode(),overlap.getLayerId(),overlap.getTimestamps());
		
		DumpFunctions.DUMP ("  bid_indic="+overlap.getBidChangeIndicator()+"  ask_indic="+overlap.getAskChangeIndicator());
		DumpFunctions.DUMP("bid side");
		++DumpFunctions.indent_count;
		DumpFunctions.dumpMbl (overlap.getBidLimits());
		--DumpFunctions.indent_count;
		DumpFunctions.DUMP("ask side");
		++DumpFunctions.indent_count;
		DumpFunctions.dumpMbl (overlap.getAskLimits());
		--DumpFunctions.indent_count;
		if (null != overlap.getOtherValues())
		{
			DumpFunctions.DUMP("OtherValues: "); DumpFunctions.dump(overlap.getOtherValues());	
		}

		// update "cached" data
		MBLSnapshot snapshot = getOrCreateSnapshot(overlap.getCode());
		if (null != snapshot)
		{
			DumpFunctions.DUMP ("== updated mbl");
			DumpFunctions.dump (snapshot.update_with_MBLOverlapRefresh(overlap));
		}
	}


	public void quotNotifMBLDeltaRefresh(
			int subscription_num,
			Object user_context,	
			MBLDeltaRefresh delta)
	{
		System.out.print("OD ");

		DumpFunctions.dumpMblHeader(delta.getCode(),delta.getLayerId(),delta.getTimestamps());
		
		DumpFunctions.dumpAction(delta.getAction());
		DumpFunctions.DUMP ( " level="+delta.getLevel()+ " price="+delta.getPrice()+ "  cumulated_qty="+delta.getCumulatedUnits()
							+ " nb_orders="+Constants.print_nbOrders(delta.getNbOrders()) 
							+ (delta.getContinuationFlag() ? " cont":""));	
	
		// update "cached" data
		MBLSnapshot snapshot = getOrCreateSnapshot(delta.getCode());
		if (null != snapshot)
		{
			DumpFunctions.DUMP ("== updated mbl");
			DumpFunctions.dump (snapshot.update_with_MBLDeltaRefresh(delta));
		}
	}
	
	public void quotNotifMBLMaxVisibleDepth	(	
			int subscription_num,
			Object user_context,
			MBLMaxVisibleDepth depth)
	{
		System.out.print("OV ");	
		DumpFunctions.DUMP ("  instrument="+depth.getCode() + "  layer_id="+depth.getLayerId() + "  maxVisibleDepth="+depth.getMaxVisibleDepth());	
			
		MBLSnapshot snapshot = getOrCreateSnapshot(depth.getCode());
		if (null != snapshot)
		{
			DumpFunctions.DUMP ("== updated mbl");
			DumpFunctions.dump (snapshot.update_with_MBLMaxVisibleDepth (depth));
		}
	}
	
	public void quotChgSubscribeInstrumentsAddInstrumentsMBLResponse (	
			Object user_context,		
			int rc,
			PolymorphicInstrumentCode[] InternalCodes
	)
	{
		if (Constants.RC_OK != rc)
		{
			System.err.println("error in syncQuotChgSubscribeInstrumentsMBL_addInstruments: " + PDU.getErrorCodeName (rc));
		}
	}

	public void quotChgSubscribeInstrumentsRemoveInstrumentsMBLResponse (	
			Object user_context,		
			int rc				
	)
	{
		if (Constants.RC_OK != rc)
		{
			System.err.println("error in syncQuotChgSubscribeInstrumentsMBL_removeInstruments: " + PDU.getErrorCodeName (rc));
		}
	}
}



public class ASyncQuotSubInstrumentsMBL {

	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);

	public static PolymorphicInstrumentCode buildInstrumentCodeFromString(String code)
	{
		int index1 = code.indexOf('@');
		if (0 <= index1 && index1 < code.length())
		{
			return new PolymorphicInstrumentCode(code);
		}
		else
		{
			return new PolymorphicInstrumentCode(Integer.decode(code).intValue());
		}
	}
	
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	public static void demonstrate_ChgSubscriptionMBL(int subscription_num, 	PolymorphicInstrumentCode instr_codes[])
	{
		// wait a bit to let the response/notifications arrive
		System.err.println("sleeping 10 seconds");				
		System.err.flush();
		sleep (10);

		// now remove the (unique) instrument and wait a bit
		System.err.println("changing subscription, removing the instrument");
		System.err.flush();

		try {
			sync_requester.syncQuotChgSubscribeInstrumentsMBL_removeInstruments (subscription_num, instr_codes);

			// wait a bit to let the response/notifications arrive (none should arrive at this time)
			System.err.println("sleeping 10 seconds ... no event should occur");				
			System.err.flush();
			sleep (10);

		} catch (FeedOSException tfEx) {
			System.err.println("error in syncQuotChgSubscribeInstrumentsMBL_removeInstruments: " + tfEx);
		}


		// now re-add the instrument and wait a bit

		System.err.println("changing subscription, re-adding the instrument");
		System.err.flush();

		try {
			sync_requester.syncQuotChgSubscribeInstrumentsMBL_addInstruments (subscription_num, instr_codes);

			// wait a bit to let the response/notifications arrive (none should arrive at this time)
			System.err.println("sleeping 30 seconds ... Trade events may occur again");				
			System.err.flush();
			sleep (30);

		} catch (FeedOSException tfEx) {
			System.err.println("error in syncQuotChgSubscribeInstrumentsL2_addInstruments: " + tfEx);
		}
	}
	
	public static void main(String[] args) {

		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}

		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();

		PDU.SET_TRACE(System.err, true, true, false, true, false, false);
		
		if (args.length != 5) {
			System.err.println("give SERVER PORT LOGIN PASSWORD FILE|INSTRUMENT_CODE");
			System.err.println("example: localhost 8000 toto titi XEUR@FDAX1205");
			System.err.println("example: localhost 8000 toto titi 25227022");
			System.err.println("example: localhost 8000 toto titi InstrumentCodes.txt");
			return;
		}

		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String code_argument = args[4];
		FileReader fileReader = null;
		PolymorphicInstrumentCode instr_codes[];
		try
		{
			fileReader = new FileReader(code_argument);	
		}
		catch(FileNotFoundException Ex)
		{	
		}
		if (null != fileReader)
		{
			Vector<PolymorphicInstrumentCode> vecInstr = new Vector<PolymorphicInstrumentCode>(5,10);
			BufferedReader in = new BufferedReader(fileReader);			
		    try {
		    	String thisLine;
		        while ((thisLine = in.readLine()) != null) 
		        { // while loop begins here
		          vecInstr.add(buildInstrumentCodeFromString(thisLine));
		        } 
		    } 
		    catch (IOException e) {
		       System.err.println("Error: " + e);
			   return;
		    }
		    instr_codes = new PolymorphicInstrumentCode[vecInstr.size()];
		    vecInstr.toArray(instr_codes);
		}
		else
		{
			instr_codes = new PolymorphicInstrumentCode[1];
			instr_codes[0] = buildInstrumentCodeFromString(code_argument);
		}
		
		System.err.println("connecting... ");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();

		// Subscribe to MBL Layer 0 (default one) only
		int[] layer_ids = new int[1];
		layer_ids[0] = 0;
		
		System.err.println("starting subscription to book");
		System.err.flush();

		// Uncomment that line to be permissive on unknwon polymorphic codes while subscribing
		//async_requester.allow_invalid_instrument_codes();
		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotSubscribeInstrumentsMBL_start
		(
				new MySubscribeMBLReceiver(),
				new String ("user context to distinguish requests"),
				instr_codes,
				layer_ids
		);
		
		// Uncomment this line to see how to modify an ongoing MBL subscription
		//demonstrate_ChgSubscriptionMBL(subscription_num,instr_codes);
		
		System.err.println("strike a key to stop mbl subscription");
		try 
		{
			System.in.read();
		} catch(java.io.IOException IoExc)
		{}

		//
		// stop the subscription
		//
		async_requester.asyncQuotSubscribeInstrumentsMBL_stop (subscription_num);

		session.close();
		Session.shutdown_api();
	}
}
















