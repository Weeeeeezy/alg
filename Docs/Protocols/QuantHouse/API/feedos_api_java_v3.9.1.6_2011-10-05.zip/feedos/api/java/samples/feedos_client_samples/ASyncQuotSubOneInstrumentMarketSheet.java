package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author Dicharry
 */



/** 
 * sample client that subscribes to an instrument's market sheet (full depth)
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */

class MySubscribeMarketSheetReceiver implements
	Receiver_Quotation_SubscribeOneInstrumentMarketSheet
	

{
	
	MarketSheetVector my_marketsheet;
	
	public void quotsubscribeOneInstrumentMarketSheetResponse 
																(	int subscription_num,
																	Object user_context,
																	int rc,		
																	int internalcode,
																	long server_timestamp,
																	long market_timestamp,
																	MarketSheetVector snapshot
																)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription to Market Sheet failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription to Market Sheet started on "+internalcode);
			DumpFunctions.dump (snapshot);
			my_marketsheet = snapshot;
		}
	}
	
	public void quotSubscribeOneInstrumentMarketSheetUnsubNotif 
																(	int subscription_num,
																	Object user_context,
																	int rc)
	{
		DumpFunctions.DUMP ("==== Subscription to Market Sheet aborted, rc="+PDU.getErrorCodeName(rc));			
	}
	
	public void quotSubscribeOneInstrumentMarketSheetNewOrderNotif 
																(	int subscription_num,
																	Object user_context,
																	int instrument_code, 
																	long server_timestamp,
																	long market_timestamp,
																	char fix_side,
																	MarketSheetEntry entry,
																	int marketsheet_level
																)
	{
		DumpFunctions.DUMP (
				"notif_NewOrder: official_utc_timestamp="+PDU.date2ISOstring(market_timestamp)+
				", side="+fix_side+
				", order_id="+entry.getId()+
				", price="+entry.getPrice()+
				", qty="+entry.getQty()+
				", level="+marketsheet_level
				);
		
		my_marketsheet.addEntryAt(fix_side, entry, marketsheet_level);
		
		DumpFunctions.dump (my_marketsheet);
				
	}
	
	public void quotSubscribeOneInstrumentMarketSheetModifyOrderNotif 
																(	int subscription_num,
																	Object user_context,
																	int instrument_code, 
																	long server_timestamp,
																	long market_timestamp,
																	char fix_side,
																	MarketSheetEntry entry,
																	int old_level,
																	int new_level
																)
	{
		DumpFunctions.DUMP (
				"notif_ModifyOrder: official_utc_timestamp="+PDU.date2ISOstring(market_timestamp)+
				", side="+fix_side+
				", order_id="+entry.getId()+
				", price="+entry.getPrice()+
				", qty="+entry.getQty()+
				", oldlvl="+old_level+
				", newlvl="+new_level
				);
		
		my_marketsheet.modifyOrderEntry(fix_side, entry, old_level, new_level);
		
		DumpFunctions.dump (my_marketsheet);
		
	}
		
	public void quotSubscribeOneInstrumentMarketSheetRemoveOneOrderNotif 
																(	int subscription_num,
																	Object user_context,
																	int instrument_code, 
																	long server_timestamp,
																	long market_timestamp,
																	ListOfTagValue quotationcontextflags,
																	char fix_side,
																	String user_id,
																	int level
																)
	{
		DumpFunctions.DUMP (
				"notif_RemoveOneOrder: official_utc_timestamp="+PDU.date2ISOstring(market_timestamp)+
				", side="+fix_side+
				", order_id="+user_id+
				", level="+level
				);
		
		my_marketsheet.removeEntry(fix_side, user_id, level);
		
		DumpFunctions.dump (my_marketsheet);
		
	}
	
	public void quotSubscribeOneInstrumentMarketSheetRemoveAllPreviousOrdersNotif 
																(	int subscription_num,
																	Object user_context,
																	int instrument_code, 
																	long server_timestamp,
																	long market_timestamp,
																	ListOfTagValue quotationcontextflags,
																	char fix_side,
																	String user_id,
																	int level
																)
	{
		DumpFunctions.DUMP ("==== quotSubscribeOneInstrumentMarketSheetRemoveAllPreviousOrdersNotif");
		
		my_marketsheet.removeAllPreviousEntry(fix_side, user_id, level);
		
		DumpFunctions.dump (my_marketsheet);
	}
	
	public void quotSubscribeOneInstrumentMarketSheetRemoveAllOrdersNotif 
																(	int subscription_num,
																	Object user_context,
																	int instrument_code, 
																	long server_timestamp,
																	long market_timestamp,
																	ListOfTagValue quotationcontextflags,
																	char fix_side
																)
	{
		DumpFunctions.DUMP ("==== quotSubscribeOneInstrumentMarketSheetRemoveAllOrdersNotif");
		
		my_marketsheet.removeAllEntry(fix_side);
		
		DumpFunctions.dump (my_marketsheet);
	}
	
	public void quotSubscribeOneInstrumentMarketSheetRetransmissionNotif 
																(	int subscription_num,
																	Object user_context,
																	int instrument_code, 
																	long server_timestamp,
																	long market_timestamp,
																	MarketSheetVector snapshot
																)
	{
		DumpFunctions.DUMP ("==== quotSubscribeOneInstrumentMarketSheetRetransmissionNotif");
		
		my_marketsheet = snapshot;
		
		DumpFunctions.dump (my_marketsheet);
	}
	
	public void quotationNotifValuesUpdateOneInstrument	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			ListOfTagValue values)
	{
		DumpFunctions.DUMP ("==== quotationNotifValuesUpdateOneInstrument");
		DumpFunctions.dump(values);
	}
}

public class ASyncQuotSubOneInstrumentMarketSheet {
	
	
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);
 		 
	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
	
		PolymorphicInstrumentCode instr_code = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		System.err.println("starting subscription to Market Sheet on "+fos_market_id+"@"+localcode_str);
		System.err.flush();
		
		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotSubscribeOneInstrumentMarketSheet_start
			(
					new MySubscribeMarketSheetReceiver(),
					new String ("user context to distinguish requests"),
					instr_code
			);

		// wait a bit to let the response/notifications arrive
		System.err.println("Subscription number is "+subscription_num);
		System.err.println("sleeping 60 seconds");				
		System.err.flush();
		sleep (60);

		
		//
		// stop the subscription
		//
		async_requester.asyncQuotSubscribeOneInstrumentMarketSheet_stop (subscription_num);
		
		session.close();
		Session.shutdown_api();
		
	}
	
}


