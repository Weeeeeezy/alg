package feedos_client_samples;

import java.awt.BorderLayout;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;

import javax.swing.*;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/*
 * (c) Copyright 2004 FeedOS
 * All Rights Reserved.
 * 
 * @author Dicharry
 */



/** 
 * sample client that subscribes to an instrument's market sheet (full depth)
 * (instrument code is passed on the command line, as MIC & LOCALCODE_STR)
 */

class MyGraphicSubscribeMarketSheetReceiver implements
Receiver_Quotation_SubscribeOneInstrumentMarketSheet


{

	MarketSheetWindow m_window;
	MarketSheetVector my_marketsheet;

	public MyGraphicSubscribeMarketSheetReceiver(MarketSheetWindow fenetre)
	{
		m_window = fenetre;
	}

	public void quotsubscribeOneInstrumentMarketSheetResponse 
	(	int subscription_num,
			Object user_context,
			int rc,		
			int internalcode,
			long server_timestamp,
			long market_timestamp,
			MarketSheetVector snapshot
	)
	{
		if (rc != Constants.RC_OK) {
			m_window.displayLog ("==== Subscription to Market Sheet failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			m_window.displayLog ("==== Subscription to Market Sheet started");
			m_window.displayMarketSheet (snapshot);
			my_marketsheet = snapshot;
		}
	}


	public void quotSubscribeOneInstrumentMarketSheetUnsubNotif 
	(	int subscription_num,
			Object user_context,
			int rc)
	{
		m_window.displayLog ("==== Subscription to Market Sheet aborted, rc="+PDU.getErrorCodeName(rc));			
	}

	public void quotSubscribeOneInstrumentMarketSheetNewOrderNotif 
	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			char fix_side,
			MarketSheetEntry entry,
			int marketsheet_level
	)
	{
		m_window.displayLog (
				"notif_NewOrder: official_utc="+PDU.date2ISOstring(market_timestamp)+
				", side="+fix_side+
				", id="+entry.getId()+
				", ("+entry.getPrice()+
				"x"+entry.getQty()+
				"), level="+marketsheet_level
		);

		my_marketsheet.addEntryAt(fix_side, entry, marketsheet_level);

		m_window.displayMarketSheet (my_marketsheet);

	}

	public void quotSubscribeOneInstrumentMarketSheetModifyOrderNotif 
	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			char fix_side,
			MarketSheetEntry entry,
			int old_level,
			int new_level
	)
	{
		m_window.displayLog (
				"notif_ModifyOrder: official_utc="+PDU.date2ISOstring(market_timestamp)+
				", side="+fix_side+
				", id="+entry.getId()+
				", ("+entry.getPrice()+
				"x"+entry.getQty()+
				"), oldlvl="+old_level+
				", newlvl="+new_level
		);

		my_marketsheet.modifyOrderEntry(fix_side, entry, old_level, new_level);

		m_window.displayMarketSheet (my_marketsheet);

	}

	public void quotSubscribeOneInstrumentMarketSheetRemoveOneOrderNotif 
	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			ListOfTagValue quotationcontextflags,
			char fix_side,
			String user_id,
			int level
	)
	{
		m_window.displayLog (
				"notif_RemoveOneOrder: official_utc="+PDU.date2ISOstring(market_timestamp)+
				", side="+fix_side+
				", id="+user_id+
				", level="+level
		);

		my_marketsheet.removeEntry(fix_side, user_id, level);

		m_window.displayMarketSheet (my_marketsheet);

	}

	public void quotSubscribeOneInstrumentMarketSheetRemoveAllPreviousOrdersNotif 
	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			ListOfTagValue quotationcontextflags,
			char fix_side,
			String user_id,
			int level
	)
	{
		m_window.displayLog ("==== quotSubscribeOneInstrumentMarketSheetRemoveAllPreviousOrdersNotif");

		my_marketsheet.removeAllPreviousEntry(fix_side, user_id, level);

		m_window.displayMarketSheet (my_marketsheet);
	}

	public void quotSubscribeOneInstrumentMarketSheetRemoveAllOrdersNotif 
	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			ListOfTagValue quotationcontextflags,
			char fix_side
	)
	{
		m_window.displayLog ("==== quotSubscribeOneInstrumentMarketSheetRemoveAllOrdersNotif");

		my_marketsheet.removeAllEntry(fix_side);

		m_window.displayMarketSheet (my_marketsheet);
	}

	public void quotSubscribeOneInstrumentMarketSheetRetransmissionNotif 
	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			MarketSheetVector snapshot
	)
	{
		m_window.displayLog ("==== quotSubscribeOneInstrumentMarketSheetRetransmissionNotif");

		my_marketsheet = snapshot;

		m_window.displayMarketSheet (my_marketsheet);
	}
	
	public void quotationNotifValuesUpdateOneInstrument	(	int subscription_num,
			Object user_context,
			int instrument_code, 
			long server_timestamp,
			long market_timestamp,
			ListOfTagValue values)
	{
		DumpFunctions.DUMP ("==== quotationNotifValuesUpdateOneInstrument");
	}
}

public class ASyncQuotSubOneInstrumentMarketSheetGraphic {


	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);

	private static void sleep (int sec) {
		try {
			Thread.sleep(sec*1000);
		} catch(InterruptedException iEx){
		}
	}
	
	public static void main(String[] args) {

		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}

		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();

		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi XEUR FDAX1205");
			return;
		}

		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();

		PolymorphicInstrumentCode instr_code = new PolymorphicInstrumentCode(fos_market_id, localcode_str);

		System.err.println("starting subscription to Market Sheet on "+market_id_str+"@"+localcode_str);
		System.err.flush();

		MarketSheetWindow gui= new MarketSheetWindow(market_id_str+localcode_str);
		gui.setVisible(true);

		// STORE the returned value: we'll need it to stop the subscription
		int subscription_num = async_requester.asyncQuotSubscribeOneInstrumentMarketSheet_start
		(
				new MyGraphicSubscribeMarketSheetReceiver(gui),
				new String ("user context to distinguish requests"),
				instr_code
		);

		// wait a bit to let the response/notifications arrive
		System.err.println("Subscription number is "+subscription_num);			
		System.err.flush();

		sleep(60000);
		
		//
		// stop the subscription
		//
		async_requester.asyncQuotSubscribeOneInstrumentMarketSheet_stop (subscription_num);

		session.close();
		Session.shutdown_api();

	}

}

class MarketSheetWindow extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private String m_title;
	private boolean refresh = true;
	
	private JTextArea buy, sell, log;
	private JPanel panel;
	private JButton freezButton;

	public MarketSheetWindow(String title){
		super();
		m_title = title;
		build();
	}

	public void build() {
		this.setTitle(m_title);
		this.setSize(600,900);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		buy = new JTextArea("",5,25);
		
		sell = new JTextArea("",5,25);
		log = new JTextArea("",10,5);
		
		panel = new JPanel(new BorderLayout()); 

		freezButton = new JButton();
		freezButton.setText("Freez the market sheet");
		freezButton.addActionListener(this);
		
		panel.add(new JScrollPane(buy), BorderLayout.WEST);
		panel.add(new JScrollPane(sell), BorderLayout.EAST);
		panel.add(new JScrollPane(log), BorderLayout.SOUTH);
		panel.add(freezButton, BorderLayout.NORTH);
		
		this.setContentPane(panel);
	}

	public void displayLog(String log_text)
	{
		if(refresh) log.insert(log_text+"\n", 0);		
	}

	public void displayMarketSheet(MarketSheetVector marketsheet)
	{
		Vector<MarketSheetEntry> entry;
		String display;

		if(!refresh) return;
		
		entry = marketsheet.getBuySide();
		buy.setText("");	
		for (int index=0; index<entry.size(); ++index) {
			display = 
			((MarketSheetEntry)entry.elementAt(index)).getId()+"\tx"+
			((MarketSheetEntry)entry.elementAt(index)).getQty()+"\t"+
			Constants.print_price(((MarketSheetEntry)entry.elementAt(index)).getPrice()) + "\n";
			buy.append(display);
		}
		
		entry = marketsheet.getSellSide();
		sell.setText("");	
		for (int index=0; index<entry.size(); ++index) {
			display = 
				Constants.print_price(((MarketSheetEntry)entry.elementAt(index)).getPrice())+"\tx"+
				((MarketSheetEntry)entry.elementAt(index)).getQty()+"\t"+
				((MarketSheetEntry)entry.elementAt(index)).getId()+"\n";
			sell.append(display);
		}
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == freezButton) {
			if(refresh) {
				refresh = false;
				freezButton.setText("Unfreez the market sheet");
			} else {
				refresh = true;
				freezButton.setText("Freez the market sheet");
			}

		}
	}

}
