package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;
import java.util.Scanner;

/*
 * (c) Copyright 2011 FeedOS
 * All Rights Reserved.
 */

class MyReferentialDownloadAndSubscribeReceiver implements Receiver_Referential_DownloadAndSubscribe
{
    
	public void refDownloadAndSubscribeResponse ( int subscription_num,
			Object user_context,
			int rc	)
	{
		System.out.println("...refReferentialDownloadAndSubscribeResponse ");
	}

	public void refDownloadAndSubscribeFailed ( int subscription_num,
			Object user_context,
			int rc	)
	{
		System.out.println("...refReferentialDownloadAndSubscribeFailed");
	}
	
	public void refDownloadAndSubscribeUnsubNotif ( int subscription_num,
				Object user_context,
				int rc	)
	{
		System.out.println("...refReferentialDownloadAndSubscribeUnsubNotif");
	}
	
	public void refDownloadBranchBegin ( MarketBranchId list_markets,
					int in_current_quantity, 
					int in_deleted_quantity, 
					int in_created_quantity, 
					int in_modified_quantity )
	{
		System.out.println("...refReferentialDownloadAndSubscribeBranchBegin");
		DumpFunctions.dump( list_markets );
		System.out.println(in_current_quantity+";"+in_deleted_quantity+";"+in_created_quantity+";"+in_modified_quantity);
	}
	
	public void refDownloadInstrumentsCreated ( InstrumentCharacteristics[] characs)
	{
		System.out.println("...refReferentialDownloadAndSubscribeInstrumentsCreated");
		DumpFunctions.dump( characs );
	}
	
	public void refDownloadInstrumentsModified ( InstrumentCharacteristics[] characs)
	{
		System.out.println("...refReferentialDownloadAndSubscribeInstrumentsModified");
		DumpFunctions.dump( characs );
	}
	
	public void refDownloadInstrumentsDeleted ( PolymorphicInstrumentCode[] instruments)
	{
		System.out.println("...refReferentialDownloadAndSubscribeInstrumentsDeleted");
		DumpFunctions.dump( instruments );
	}
	
	public void refDownloadAndSubscribeMarkerTimestamp(long marker_timestamp)
	{
		System.out.println("...refReferentialDownloadAndSubscribeMarkerTimestamp "+PDU.date2ISOstring(marker_timestamp));	
	}
	
	public void refDownloadAndSubscribeRealtimeBegin()
	{
		System.out.println("...realtime referential events starts");
	}
}

public class ASyncRefDownloadAndSubscribe {
	
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static RequestSender async_requester = new RequestSender (session, 0);

	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_ASyncRefDownloadAndSubscribe")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length < 4) {
			System.err.println("give SERVER PORT LOGIN PASSWORD");
			System.err.println("example: localhost 8000 toto titi");
			return;
		}
		
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		int fos_market_id;
		if(args.length == 5)
		{
			String market_id_str = args[4];
			fos_market_id = Verbosity.getFOSMarketId (market_id_str);
			if (0==fos_market_id) {
				System.err.println("unknown MIC: "+market_id_str);
				return;
			}
		} else
		{
			// download referential for all markets
			fos_market_id = 0;
		}

		MarketBranchId[] branch_ids = new MarketBranchId[1];
		branch_ids[0] = new MarketBranchId(fos_market_id,"","");
		
		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		System.err.flush();
		
		MyReferentialDownloadAndSubscribeReceiver receiver = new MyReferentialDownloadAndSubscribeReceiver();
		
		int[] dump_format = {
				//Constants.TAG_LocalCodeStr,
				//Constants.TAG_Symbol,
				//Constants.TAG_SecurityType,
				//Constants.TAG_SecuritySubType,
				//Constants.TAG_CFICode,
//				Constants.TAG_Description,
				//Constants.TAG_MaturityYear,
//				Constants.TAG_MaturityMonth,
//				Constants.TAG_MaturityDay,
//				Constants.TAG_StrikePrice,
//				Constants.TAG_ISIN,
		};	

		/// try playing with the filter
		//ListOfTagValue filter = new ListOfTagValue();
		//filter.enforceTagValue(Constants.TAG_SecurityType, Any.make_string("FUT"));
		//filter.enforceTagValue(Constants.TAG_SecuritySubType, Any.make_string("FENE"));
		//filter.enforceTagValue(Constants.TAG_LocalCodeStr, Any.make_string("F0BQ0707"));
		//filter.enforceTagValue(Constants.TAG_CFICode, Any.make_string("FCX"));
		//filter.enforceTagValue(Constants.TAG_MaturityYear, Any.make_uint16(2007));
		//filter.forbidTag (Constants.TAG_MaturityYear);
		/// try playing with the filter
		ListOfTagValue	filter = null;
		filter = new ListOfTagValue();
		//filter.enforceTagValue(Constants.TAG_LocalCodeStr, Any.make_string("F0BQ0707"));
		//filter.enforceTagValue(Constants.TAG_SecurityType, Any.make_string("FUT"));
//		filter.forbidTag (RequestSender.TAG_InternalMagic_0);
		//filter.enforceTagValue(Constants.TAG_MaturityYear, Any.make_uint16(2008));
		
		int subscription_id = async_requester.asyncRefDownloadAndSubscribe_start(
				receiver, 
				new String ("user context to distinguish requests"), 
				branch_ids, 
				filter, 
				dump_format, 
				0, 
				true, 
				true,
				true,
				false);
		
	    Scanner sc = new Scanner(System.in);
	    sc.nextLine();
		
		//
		// stop the subscription
		//
		System.err.println("stopping subscription");
		System.err.flush();
		
		async_requester.asyncRefDownloadAndSubscribe_stop (subscription_id);
		
		session.close();
		Session.shutdown_api();
	}

	
}