package feedos_client_samples;

import java.util.Date;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;



/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

class MyFeedPublisherClient_L1 implements 
Receiver_Publish_FeedPublisher
{
	public void publishGenerateTradeEventExtResponse (	Object user_context,int rc) { System.err.println("on publishGenerateTradeEventExtResponse, rc="+rc); }
	public void publishGenerateOrderBookRefreshResponse (	Object user_context, int rc	) { System.err.println("on publishGenerateOrderBookRefreshResponse, rc="+rc); }
	public void publishGenerateOrderBookDeltaRefreshResponse (	Object user_context,int rc) { System.err.println("on publishGenerateOrderBookDeltaRefreshResponse, rc="+rc); }
	public void publishGenerateOrderBookMaxVisibleDepthResponse (	Object user_context,int rc) { System.err.println("on publishGenerateOrderBookMaxVisibleDepthResponse, rc="+rc); }
}

public class FeedPublishSample_L1 
{

	static MyFeedPublisherClient_L1 receiver = new MyFeedPublisherClient_L1();
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static FeedPublisher publisher = new FeedPublisher(receiver,session);
	
	public static void main(String[] args) {
				
		if (0 != Session.init_api("sample_FeedPublisher_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable "pretty values" for ReturnCodes, MarketIDs, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi  XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];
		
		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];
		
		PolymorphicInstrumentCode instrument = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		
		Date m_date = new Date();
		/* 
		 * generate trades 
		 */
		{
			publisher.quot_simple_generate_trade(instrument, m_date.getTime(), 15, 1);
			publisher.quot_simple_generate_trade(instrument, m_date.getTime(), 14.5, 3);
			publisher.quot_simple_generate_trade(instrument, m_date.getTime(), 18, 6);
			publisher.quot_simple_generate_trade(instrument, m_date.getTime(), 16.5, 2);
			publisher.quot_simple_generate_trade(instrument, m_date.getTime(), 15, 12);
		}
					
		/* 
		 * generate last price 
		 */
		{
			publisher.quot_simple_generate_last_price(instrument, 0, 18.5); // null market time
		}
	
		/* 
		 * generate values
		 */
		{
			// a single value
			publisher.quot_simple_generate_other_value(instrument, 0, Constants.TAG_DailySettlementPrice, 15);
			
			// multiple values
			ListOfTagValue values = new ListOfTagValue();
			values.addTag(Constants.TAG_DailyHighPrice, Any.make_float64(18.5));
			values.addTag(Constants.TAG_DailyClosingPrice, Any.make_float64(15.5));
			
			publisher.quot_simple_generate_other_values(instrument, 0, values);
		}
		
		/*
		 * some best limit updates
		 */
		{
			publisher.quot_simple_generate_best_limits(instrument, m_date.getTime(), 10, 2, 1, 12, 4, 2);
			publisher.quot_simple_generate_best_limits(instrument, m_date.getTime(), 10, 3, 1, 12, 5, 1);
			publisher.quot_simple_generate_best_limits(instrument, m_date.getTime(), 10.5, 6, 1, 11, 4, 3);
			publisher.quot_simple_generate_best_limits(instrument, m_date.getTime(), 10, 6, Constants.ORDERBOOK_NB_ORDERS_UNKNOWN, 12, 2, Constants.ORDERBOOK_NB_ORDERS_UNKNOWN);
			
	

		}
		
		
		/* 
		 * reset best limit
		 */
		{
			double dummy_price = 999;
			double dummy_qty = 999;
			
			publisher.quot_simple_generate_best_limits(instrument, m_date.getTime(), 
					dummy_price, dummy_qty, Constants.ORDERBOOK_NB_ORDERS_EMPTY, // bid
					dummy_price, dummy_qty, Constants.ORDERBOOK_NB_ORDERS_EMPTY); // ask
		}
	
		session.close();
		Session.shutdown_api();
	}
	
}
