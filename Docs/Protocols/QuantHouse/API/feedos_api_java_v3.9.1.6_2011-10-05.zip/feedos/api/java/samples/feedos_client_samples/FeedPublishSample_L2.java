package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;



/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

class MyFeedPublisherClient_L2 implements 
Receiver_Publish_FeedPublisher
{
	public void publishGenerateTradeEventExtResponse (	Object user_context,int rc) { System.err.println("on publishGenerateTradeEventExtResponse, rc="+rc); }
	public void publishGenerateOrderBookRefreshResponse (	Object user_context, int rc	) { System.err.println("on publishGenerateOrderBookRefreshResponse, rc="+rc); }
	public void publishGenerateOrderBookDeltaRefreshResponse (	Object user_context,int rc) { System.err.println("on publishGenerateOrderBookDeltaRefreshResponse, rc="+rc); }
	public void publishGenerateOrderBookMaxVisibleDepthResponse (	Object user_context,int rc) { System.err.println("on publishGenerateOrderBookMaxVisibleDepthResponse, rc="+rc); }
}

public class FeedPublishSample_L2
{

	static MyFeedPublisherClient_L2 receiver = new MyFeedPublisherClient_L2();
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static FeedPublisher publisher = new FeedPublisher(receiver,session);
	
	public static void main(String[] args) {
				
		if (0 != Session.init_api("sample_FeedPublisher_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable "pretty values" for ReturnCodes, MarketIDs, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 6) {
			System.err.println("give SERVER PORT LOGIN PASSWORD   MARKET_CODE  LOCAL_CODE_STR");
			System.err.println("example: localhost 8000 toto titi  XEUR FDAX1205");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];
		
		String market_id_str = args[4];
		int fos_market_id = Verbosity.getFOSMarketId (market_id_str);
		if (0==fos_market_id) {
			System.err.println("unknown MIC: "+market_id_str);
			return;
		}
		String localcode_str = args[5];
		
		PolymorphicInstrumentCode instrument = new PolymorphicInstrumentCode(fos_market_id, localcode_str);
		
		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		
		/* 
		 * generate full book 
		 */
		{
			OrderBookSide BidLimits = new OrderBookSide();
			OrderBookSide AskLimits = new OrderBookSide();
			
			BidLimits.appendEntry(15, 67);
			BidLimits.appendEntry(14.5, 12);
			BidLimits.appendEntry(13, 44);
			
			AskLimits.appendEntry(16.5, 12);
			AskLimits.appendEntry(17, 25);
			AskLimits.appendEntry(18, 65);
			
			publisher.quot_simple_generate_full_book(instrument, BidLimits, AskLimits);
		}
					
		/* 
		 * generate delta
		 */
		{
			publisher.quot_GenerateOrderBookDeltaRefresh(instrument, Constants.OrderBookDeltaAction_AskChangeQtyAtLevel, 0, 0, 22);
			publisher.quot_GenerateOrderBookDeltaRefresh(instrument, Constants.OrderBookDeltaAction_BidChangeQtyAtLevel, 0, 0, 14);
		}
	
		/* 
		 * empty book
		 */
		{
			publisher.quot_GenerateOrderBookMaxVisibleDepth(instrument, 0);
		}
		
		session.close();
		Session.shutdown_api();
	}
	
}
