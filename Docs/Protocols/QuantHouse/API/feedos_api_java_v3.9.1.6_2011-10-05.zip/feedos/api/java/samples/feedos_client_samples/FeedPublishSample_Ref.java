package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2008 FeedOS
 * All Rights Reserved.
 * 
 * @author dicharry
 */

class MyFeedPublisherClient_Ref implements 
Receiver_Publish_FeedPublisher
{
	public void publishGenerateTradeEventExtResponse (	Object user_context,int rc) { System.err.println("on publishGenerateTradeEventExtResponse, rc="+rc); }
	public void publishGenerateOrderBookRefreshResponse (	Object user_context, int rc	) { System.err.println("on publishGenerateOrderBookRefreshResponse, rc="+rc); }
	public void publishGenerateOrderBookDeltaRefreshResponse (	Object user_context,int rc) { System.err.println("on publishGenerateOrderBookDeltaRefreshResponse, rc="+rc); }
	public void publishGenerateOrderBookMaxVisibleDepthResponse (	Object user_context,int rc) { System.err.println("on publishGenerateOrderBookMaxVisibleDepthResponse, rc="+rc); }
}

public class FeedPublishSample_Ref 
{

	static MyFeedPublisherClient_Ref receiver = new MyFeedPublisherClient_Ref();
	static MySessionObserver session_observer = new MySessionObserver();
	static Session session = new Session();		
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);
	static FeedPublisher publisher = new FeedPublisher(receiver,session);
	
	public static void main(String[] args) {
				
		if (0 != Session.init_api("sample_FeedPublisher_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable "pretty values" for ReturnCodes, MarketIDs, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 4) {
			System.err.println("give SERVER PORT LOGIN PASSWORD");
			System.err.println("example: localhost 8000 toto titi");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];
		
		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		
		/* 
		 * create instrument 
		 */
		int internal_code;
		{
			ListOfTagValue	new_instrument = new ListOfTagValue();
			new_instrument.addTag(Constants.TAG_FOSMarketId, Any.make_uint16(Verbosity.getFOSMarketId("XPAR")));
			new_instrument.addTag(Constants.TAG_Symbol, Any.make_string("my_Symbol"));
			new_instrument.addTag(Constants.TAG_LocalCodeStr, Any.make_string("my_LocalCodeStr"));	
			new_instrument.addTag(Constants.TAG_CFICode, Any.make_string("EXXXXX"));
			new_instrument.addTag(Constants.TAG_SecurityType, Any.make_string("CS"));
			
			internal_code = publisher.ref_AllocateNewInstrument(new_instrument, Constants.AllocateNewInstrumentPolicy_ResetAndOverwrite);
			
			if(internal_code == 0)
			{
				System.err.println("Cannot create instrument");
				//return;
			}
			else
			{
				System.err.println("Instrument created code="+internal_code);
			}
		}
				
		// display instrument
		PolymorphicInstrumentCode[] codes = new PolymorphicInstrumentCode[1];
		codes[0] = new PolymorphicInstrumentCode(internal_code);
		ref_getInstrument(codes);		
		
		
		/* 
		 * update instrument 
		 */
		{
			ListOfTagValue	new_instrument = new ListOfTagValue();
			
			new_instrument.addTag(Constants.TAG_Symbol, Any.make_string("my_Updated_Symbol"));
			new_instrument.addTag(Constants.TAG_LocalCodeStr, Any.make_string("my_LocalCodeStr"));	
			new_instrument.addTag(Constants.TAG_CFICode, Any.make_string("ECXXXX"));
			new_instrument.addTag(Constants.TAG_SecurityType, Any.make_string("PS"));
			
			publisher.ref_UpdateInstrumentAttributes(codes[0], new_instrument);
			
			// display instrument
			System.err.println("Instrument updated: "+internal_code);
			ref_getInstrument(codes);
		}
		
		
		/* 
		 * remove instrument 
		 */
		{
			publisher.ref_UnallocateInstruments(codes);
			System.err.println("Instrument removed: "+internal_code);
			
			// display instrument (should fail)
			ref_getInstrument(codes);
		}
	
		session.close();
		Session.shutdown_api();
	}
	
	private static void ref_getInstrument(PolymorphicInstrumentCode[] codes)
	{
		try
		{
			InstrumentCharacteristics[] result =  sync_requester.syncRefGetInstruments(codes, null);
			
			System.err.println("instrument data:");
			DumpFunctions.dump(result);
		} catch (FeedOSException tfEx) {
			System.err.println("error in synchronous processing: " + tfEx);
			return;
		}	

	}
}
