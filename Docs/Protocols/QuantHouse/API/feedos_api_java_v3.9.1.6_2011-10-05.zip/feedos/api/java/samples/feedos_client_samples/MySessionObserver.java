package feedos_client_samples;

import com.feedos.api.core.*;


/*
 * (c) Copyright 2004 FeedOS
 * All Rights Reserved.
 * 
 * @author fenouil
 */


/** 
 * sample "Observer" for reacting to session events
 */

class MySessionObserver implements SessionObserver {

	public static void DUMP (String s) {
		System.out.println(s);
		System.out.flush();
	}

	//---------------------------------------------------------------------------                                                                                
	//							ProxyObserver
	//---------------------------------------------------------------------------

	public void sessionOpened (Session proxy, int heartbeat_period_sec, int uid, int gid)
	{
		DUMP("MySessionObserver: session opened, heartbeat_period_sec = " + heartbeat_period_sec);
		DUMP("User ID : " + uid + ", Group ID : " +gid);
	}

	/// heartbeat signal from server
	public void heartbeat (Session proxy, long heartbeat_period_sec) {
		DUMP("MySessionObserver: session heartbeat, server_date = " + PDU.date2ISOstring(heartbeat_period_sec));
	}

	public void adminMessage (Session proxy, boolean isUrgent, String origin, String headline, String content) {

		String adminMessage = "MySessionObserver: admin message: ";
		if(isUrgent) adminMessage+=("[URGENT]");
		adminMessage+= origin + " " + headline + " " + content; 
		DUMP(adminMessage);
	}
	/// connection with server has been lost. pending requests are about to be terminated
	public void closeInProgress (Session proxy) {
		DUMP("MySessionObserver: session closeInProgress");
		// TODO: set a flag to disable error-handling of pending requests ?
	}

	/// connection with server has been lost. pending requests have been terminated
	public void closeComplete (Session proxy) {
		DUMP("MySessionObserver: session closeComplete");
		// TODO: synchronously reopen session ?
	}

}


