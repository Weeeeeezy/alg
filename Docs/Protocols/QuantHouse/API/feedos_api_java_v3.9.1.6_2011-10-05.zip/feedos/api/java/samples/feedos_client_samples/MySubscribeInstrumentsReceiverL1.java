package feedos_client_samples;

import java.util.Hashtable;

import com.feedos.api.core.PDU;
import com.feedos.api.core.PolymorphicInstrumentCode;
import com.feedos.api.requests.Constants;
import com.feedos.api.requests.InstrumentQuotationData;
import com.feedos.api.requests.QuotationTradeEventExt;
import com.feedos.api.requests.Receiver_Quotation_ChgSubscribeInstrumentsL1;
import com.feedos.api.requests.Receiver_Quotation_SubscribeInstrumentsL1;

class MySubscribeInstrumentsReceiverL1 implements 
		Receiver_Quotation_SubscribeInstrumentsL1, Receiver_Quotation_ChgSubscribeInstrumentsL1
{
	// let's store "instrument status" values, indexed by internal_code
	Hashtable<Integer, InstrumentQuotationData> instrMap = new Hashtable<Integer, InstrumentQuotationData>();

	PolymorphicInstrumentCode[] input_instr_codes;
	
	// pass the list of "polymorphic codes" that this receiver is supposed to handle.
	// This will be used to "enrich" instrument codes received.
	MySubscribeInstrumentsReceiverL1 (PolymorphicInstrumentCode[] the_instr_codes)
	{
		input_instr_codes = the_instr_codes;
	}

	
	public void quotSubscribeInstrumentsL1Response (
			int subscription_num,
			Object user_context,
			int rc,						
			InstrumentQuotationData[] result
		)
	{
		if (rc != Constants.RC_OK) {
			DumpFunctions.DUMP ("==== Subscription failed, rc="+PDU.getErrorCodeName(rc));			
		} else {
			DumpFunctions.DUMP ("==== Subscription started");
			DumpFunctions.dump (result);
			
			// create new entries in the map, one per instrument received
			for (int i=0; i<result.length; ++i) {
				PolymorphicInstrumentCode instr = result[i].getInstrumentCode();
				
				//int internal_instr_code = instr.instrument_code.get_internal_code();
				int internal_instr_code = instr.get_internal_code();
				
				if (0 == internal_instr_code) {
					// this may happen: 
					// 1) an invalid instr code was provided in request 
					// 2) IgnoreInvalidCodes was set to true (hence the request succeded despite the invalid input)
				} else {

					// enrich the instrument code because:
					// 1) only the "local code" flavour was set in the request
					// 2) only the "internal" flavour is present in the response data
					instr.merge_local_code(input_instr_codes[i].get_local_code_str());					
					input_instr_codes[i].merge_internal_code(instr.get_internal_code());
					
					// create the entry
					instrMap.put (new Integer (internal_instr_code), result[i]);
				}
			}
		}
	}

	public void declareEndOfSubscription (
			int subscription_num,
			Object user_context,
			int rc)
	{
		quotSubscribeInstrumentsL1UnsubNotif(subscription_num, user_context, rc);
	}
	
	public void quotSubscribeInstrumentsL1UnsubNotif (
			int subscription_num,
			Object user_context,
			int rc)
	{
		DumpFunctions.DUMP ("==== Subscription ended: " +input_instr_codes.length);
		
		for(int i = 0; i < input_instr_codes.length; ++i )
		{
			DumpFunctions.dump (instrMap.get(input_instr_codes[i].get_internal_code()));
		}
	}
		
	public void quotNotifTradeEventExt (
			int subscription_num,
			Object user_context,	
			int instrument_code, 
			long server_timestamp, 
			long market_timestamp, 
			QuotationTradeEventExt trade_event)
	{
		
		instrMap.get(instrument_code).update_with_TradeEventExt(server_timestamp, trade_event);
		
		String market_timestamp_str = PDU.date2ISOstring(market_timestamp);
		String server_timestamp_str = PDU.date2ISOstring(server_timestamp);
		
		DumpFunctions.DUMP ("==== " + server_timestamp_str + "\t" + market_timestamp_str);
		++DumpFunctions.indent_count;

		//
		// now parse the event and dump values
		//
		
		// check best limits
		if (trade_event.content_mask.isSetBidLimit()) {
			DumpFunctions.DUMP ("BEST BID: "+trade_event.best_bid_price+ " x "+ trade_event.best_bid_qty);			
		}
		if (trade_event.content_mask.isSetAskLimit()) {
			DumpFunctions.DUMP ("BEST ASK: "+trade_event.best_ask_price+ " x "+ trade_event.best_ask_qty);			
		}
		
		String flags = "";
		if (trade_event.content_mask.isSetOCHLdaily()) { flags += "<daily> "; }
		if (trade_event.content_mask.isSetOpen()) { flags += "OPEN "; }
		if (trade_event.content_mask.isSetClose()) { flags += "CLOSE "; }
		if (trade_event.content_mask.isSetHigh()) { flags += "HIGH "; }		
		if (trade_event.content_mask.isSetLow()) { flags += "LOW "; }

		if (flags.length() != 0) {
			DumpFunctions.DUMP ("flags: "+flags);	
		}
		
		// check price/trade update
		if (trade_event.content_mask.isSetLastPrice()) {
			if (trade_event.content_mask.isSetLastTradeQty()) {
				if(trade_event.content_mask.isSetOffBookTrade())
				{
					DumpFunctions.DUMP ("OFFTRADE: "+trade_event.price + " x "+ trade_event.last_trade_qty);
				}
				else
				{
					DumpFunctions.DUMP ("TRADE: "+trade_event.price + " x "+ trade_event.last_trade_qty);
				}
			} else {
				DumpFunctions.DUMP ("PRICE: "+trade_event.price);				
			}			
		} else {
			if (flags.length() != 0) {
				DumpFunctions.DUMP ("OCHL value: "+trade_event.price);								
			}
		}
		
		if( trade_event.getContext().size() > 0)
			DumpFunctions.DUMP ("Context: "); DumpFunctions.dump(trade_event.getContext());
		
		if( trade_event.getValue().size() > 0)
			DumpFunctions.DUMP ("Values: "); DumpFunctions.dump(trade_event.getValue());
		
		--DumpFunctions.indent_count;	
	}
	
	public void quotChgSubscribeInstrumentsAddInstrumentsL1Response(
			Object userContext, int rc, InstrumentQuotationData[] result) {
		// TODO Auto-generated method stub
		
	}


	public void quotChgSubscribeInstrumentsAddOtherValuesToLookForL1Response(
			Object userContext, int rc, InstrumentQuotationData[] result) {
		// TODO Auto-generated method stub
		
	}


	public void quotChgSubscribeInstrumentsNewContentMaskL1Response(
			Object userContext, int rc, InstrumentQuotationData[] result) {
		// TODO Auto-generated method stub
		
	}


	public void quotChgSubscribeInstrumentsRemoveInstrumentsL1Response(
			Object userContext, int rc) {
		// TODO Auto-generated method stub
		
	}
	
}