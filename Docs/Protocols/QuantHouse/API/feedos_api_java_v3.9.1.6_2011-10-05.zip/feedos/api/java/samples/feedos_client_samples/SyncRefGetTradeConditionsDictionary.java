package feedos_client_samples;

import com.feedos.api.core.Credentials;
import com.feedos.api.core.FeedOSException;
import com.feedos.api.core.PDU;
import com.feedos.api.core.ProxyFeedosTCP;
import com.feedos.api.core.Session;
import com.feedos.api.requests.Constants;
import com.feedos.api.requests.SyncRequestSender;
import com.feedos.api.requests.TradeConditionsDictionaryEntry;
import com.feedos.api.tools.Verbosity;

public class SyncRefGetTradeConditionsDictionary {

	static Session session = new Session();		
	static MySessionObserver session_observer = new MySessionObserver();
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);
	
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_SyncRefGetTradeConditionsDictionary")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable string conversions for MarketIDs, ReturnCodes, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 4) {
			System.err.println("give SERVER PORT LOGIN PASSWORD");
			System.err.println("example: localhost 8000 toto titi");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");				
		System.err.println("sending (sync) ref.GetTradeConditionsDictionary");
		System.err.flush();

		try{
			// perform a synchronous request
			// use asyncRefGetTradeConditionsDictionary for asynchronous request. don't forget to build a receiver.
			TradeConditionsDictionaryEntry[] result = 
				sync_requester.syncRefGetTradeConditionsDictionary();
			
			// dump the result
			for(int table_index = 0; table_index<result.length; table_index++)
			{
				System.out.println(result[table_index].printContent());
			}
			
		} catch (FeedOSException tfEx) {
			System.err.println("error in synchronous processing: " + tfEx);
			return;
		}

		session.close();
		Session.shutdown_api();
	}
	
}
