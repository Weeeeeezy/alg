package feedos_client_samples;

import com.feedos.api.core.*;
import com.feedos.api.requests.*;
import com.feedos.api.tools.Verbosity;


/*
 * (c) Copyright 2004 FeedOS
 * All Rights Reserved.
 * 
 * @author fenouil
 */
 


/** 
 * sample client that performs a "referential lookup" on a FeedOS server
 * from a pattern string, passed on the command line
 */

public class SyncRefLookup {
			
	static Session session = new Session();		
	static MySessionObserver session_observer = new MySessionObserver();
	static SyncRequestSender sync_requester = new SyncRequestSender (session, 0);
 		 
	public static void main(String[] args) {
		
		if (0 != Session.init_api("sample_app")) {
			System.err.println(" cannot initialise FeedOS API ");
			return;
		}
		
		// enable "pretty values" for ReturnCodes, MarketIDs, Tag Numbers, etc.
		Verbosity.enableVerbosity();
	
		if (args.length != 5) {
			System.err.println("give SERVER PORT LOGIN PASSWORD  lookup-pattern");
			System.err.println("example: localhost 8000 toto titi alcatel");
			return;
		}
			
		// filled from arguments
		String server = args[0];
		int port = Integer.decode (args[1]).intValue();
		String login= args[2];
		String password = args[3];

		String lookup_pattern = args[4]; 
		
		System.err.println("connecting...");
		int rc=session.open	(session_observer, new ProxyFeedosTCP(server, port, new Credentials(login, password)), 0);

		if (rc!=Constants.RC_OK){
			System.err.println("Cannot connect: rc="+PDU.getErrorCodeName (rc));
			return;
		}
		System.err.println("connection OK");
		
		
		/// try playing with the filter
		ListOfTagValue	filter = null;
		filter = new ListOfTagValue();
	//	filter.enforceTagValue(Constants.TAG_SecurityType, Any.make_string("FUT"));
//		filter.forbidTag (RequestSender.TAG_InternalMagic_0);
	//	filter.enforceTagValue(Constants.TAG_MaturityYear, Any.make_uint16(2008));
		
		System.err.println("sending ref.lookup with pattern='"+lookup_pattern+"'");
		try{
			// perform a synchronous Ref.Lookup
			InstrumentCharacteristics[] result = 
				sync_requester.syncRefLookup (	lookup_pattern,		// pattern
												10,					// max hits
												false,				// mode = WIDE
												filter,				// optional filter
												null				// send all attributes
											);
			
			// dump the resulting instruments
			DumpFunctions.dump(result);
			
		} catch (FeedOSException tfEx) {
			System.err.println("error in synchronous processing: " + tfEx);
			return;
		}
						
		session.close();
		Session.shutdown_api();
	}
	
	
	
		
}
















